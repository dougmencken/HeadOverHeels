#ifndef __al_included_allegro5_aintern_direct3d_h
#define __al_included_allegro5_aintern_direct3d_h

#ifdef __cplusplus
extern "C" {
#endif


struct ALLEGRO_DISPLAY_D3D;

AL_FUNC(void, _al_d3d_set_blender, (struct ALLEGRO_DISPLAY_D3D *disp));


#ifdef __cplusplus
}
#endif

#endif
