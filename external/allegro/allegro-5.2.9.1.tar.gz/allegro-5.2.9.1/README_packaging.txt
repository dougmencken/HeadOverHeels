Note to packagers (e.g. for Linux distributions)
------------------------------------------------

Allegro 5.x is *not* source compatible with Allegro 4.2.x or 4.4.x.
When packaging Allegro 5, please make it possible for users to install
Allegro 4.x and 5.x simultaneously.  For example, if you already have
an 'allegro' package, then you might name the new package 'allegro5'.

