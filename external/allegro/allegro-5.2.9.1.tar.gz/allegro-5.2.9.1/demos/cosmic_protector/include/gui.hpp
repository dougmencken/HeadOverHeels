#ifndef GUI_HPP
#define GUI_HPP

int do_menu(void);
void do_highscores(int score);

#endif // GUI_HPP

