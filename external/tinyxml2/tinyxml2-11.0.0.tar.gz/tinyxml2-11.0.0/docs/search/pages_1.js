var searchData=
[
  ['an_20xml_20file_0',['Load an XML File',['../_example_1.html',1,'']]],
  ['an_20xml_20from_20char_20buffer_1',['Parse an XML from char buffer',['../_example_2.html',1,'']]],
  ['and_20text_20information_2',['Read attributes and text information.',['../_example_4.html',1,'']]],
  ['attributes_20and_20text_20information_3',['Read attributes and text information.',['../_example_4.html',1,'']]]
];
