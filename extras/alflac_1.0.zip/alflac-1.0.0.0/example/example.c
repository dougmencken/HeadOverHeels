
#include <alflac.h>
#include <allegro.h>

#define KILOBYTE (1<<10)


int basic_allegro_start(){
   if (allegro_init() != 0)
      return 1;
   install_keyboard(); 
   install_timer();

   if (set_gfx_mode(GFX_AUTODETECT_WINDOWED, 320, 200, 0, 0) != 0) {
      if (set_gfx_mode(GFX_SAFE, 320, 200, 0, 0) != 0) {
	 set_gfx_mode(GFX_TEXT, 0, 0, 0, 0);
	 allegro_message("Unable to set any graphic mode\n%s\n",
			 allegro_error);
	 return 1;
      }
   }

   set_palette(desktop_palette);
   clear_to_color(screen, makecol(255, 255, 255));

   /* install a digital sound driver */
   if (install_sound(DIGI_AUTODETECT, MIDI_NONE, NULL) != 0) {
      set_gfx_mode(GFX_TEXT, 0, 0, 0, 0);
      allegro_message("Error initialising sound driver\n%s\n",
		      allegro_error);
      return 1;
   }

   /* we want a _real_ sound driver */
   if (digi_card == DIGI_NONE) {
      set_gfx_mode(GFX_TEXT, 0, 0, 0, 0);
      allegro_message("Unable to find a sound driver\n%s\n",
		      allegro_error);
      return 1;
   }
   
   return 0;
}

void usage(){
   printf("Usage:\n\tEXAMPLE {play | stream | data | save} filename\n\nplay   Plays a .flac file, decoding it all before the start\nstream Streams a .flac file, decoding bit by bit\ndata   Loads the first item in a datafile, which must be FLAC data with the ID \"FLAW\"\nsave   Like \"play\", but saves the file to filename.wav\n\n");
}


int main(int argc, char **argv){

   printf("EXAMPLE program for %s\n%s\n", alflac_id, alflac_id_copyright);
   
   if (argc != 2 + 1){
      usage();
      return EXIT_FAILURE;
   }
   
   /* allegro */
   if (
      basic_allegro_start()
   != 0)
      return EXIT_FAILURE;
   printf("Allegro: %s\n", allegro_id);
   
   /* display */
   acquire_screen();
   clear_to_color(screen, makecol(0xff, 0xff, 0xff));
   textprintf_centre_ex(screen, font, SCREEN_W/2, 0, makecol(0,0,0), -1, "compunach.co.nr/alflac");
   release_screen();
   
   /* work in bg */
   set_display_switch_mode(SWITCH_BACKGROUND);
   
   /* load_sample registration, etc */
   alflac_for_allegro();
   
   /* pick part */
   if (stricmp(argv[1], "play") == 0) {
   
      SAMPLE *spl;
      
      printf("Opening\n");
      spl = load_sample(argv[2]);
      if (!spl) {
         printf("No SAMPLE\n");
         return EXIT_FAILURE;
      }
      
      printf("Playing\n");
      play_sample(spl, 255, 127, 1000, 1);
      
      printf("Looping (ESC= exit)\n");
      while (!key[KEY_ESC]){
         rest(50 /* ms */);
      }
      
      printf("Closing\n");
      destroy_sample(spl);
      
   } else if (stricmp(argv[1], "data") == 0) {
   
      SAMPLE *spl;
      DATAFILE *d;
      
      printf("Opening\n");
      d = load_datafile(argv[2]);
      if (!d)  {
         printf("No SAMPLE\n");
         return EXIT_FAILURE;
      }
      
      spl = d[0].dat;
      if (!spl) {
         printf("No SAMPLE\n");
         return EXIT_FAILURE;
      }
      
      printf("Playing\n");
      play_sample(spl, 255, 127, 1000, 1);
      
      printf("Looping (ESC= exit)\n");
      while (!key[KEY_ESC]){
         rest(50 /* ms */);
      }
      
      printf("Closing\n");
      unload_datafile(d);
      
   } else if (stricmp(argv[1], "stream") == 0) {
   
      ALFLAC *af;
      
      printf("Opening\n");
      af = alflac_do_file_to_audiostream(argv[2], 4*KILOBYTE);
      if (!af) {
         printf("No ALFLAC\n");
         return EXIT_FAILURE;
      }
      
      printf("Looping (ESC=exit)\n");
      while (!key[KEY_ESC]) {
         if (
            alflac_poll(af)
         <= 0)
            break;
      }
      
      printf("Closing\n");
      alflac_alflac_del(af);
      
   } else   if (stricmp(argv[1], "save") == 0) {
   
      SAMPLE *spl;
      char out_name[256];
      
      printf("Opening\n");
      spl = load_sample(argv[2]);
      if (!spl) {
         printf("No SAMPLE\n");
         return EXIT_FAILURE;
      }
      
      printf("Saving\n");
      snprintf(out_name, 256, "%s.output.wav", argv[2]);
      alflac_save_wav(out_name, spl);
      
      printf("Closing\n");
      destroy_sample(spl);
      
   } else {
   
      usage();
      return EXIT_FAILURE;
      
   }
      
   printf("OK / End\n");
   
   return EXIT_SUCCESS;
}
END_OF_MAIN()




