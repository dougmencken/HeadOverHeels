/*

Grabber plugin for FLAW (ALFLAC FLAC data) datafile object
See alflac readme

Giftware licensed code
2006 David Batley

*/

#include <strings.h>
#include <stdio.h>

#include "allegro.h"
#include "../datedit.h"


static void *makenew_alflac(long *size)
{
   char *x = malloc(2 * sizeof(char));
   strncpy(x, "NO", 2);
   *size = 2L;
   return (void*) x;
}

static int save_alflac_in_datafile(DATAFILE *dat, AL_CONST int *fixed_prop, int pack, int pack_kids, int strip, int sort, int verbose, int extra, PACKFILE *f)
{
	 pack_fwrite(dat->dat, dat->size, f);
    return TRUE;
}


static void plot_alflac(AL_CONST DATAFILE *dat, int x, int y)
{
   if (!dat->dat || dat->size < 4)
      textout_ex(screen, font, "  EMPTY  ", x, y+32, gui_bg_color, gui_fg_color);
   else if (strncmp(dat->dat, "fLaC", 4) != 0)
      textout_ex(screen, font, " This is not a FLAC file ", x, y+32, makecol(0xff, 0xff, 0xff), makecol(0xff, 0, 0));
   else
      textprintf_ex(screen, font, x, y+32, gui_fg_color, -1, "FLAC File, size: %ld MB, %ld KB, %ld bytes", (dat->size >> 20), (dat->size >> 10) % 1024L, dat->size % 1024L);
}


static int export_alflac(AL_CONST DATAFILE *dat, AL_CONST char *filename)
{
   PACKFILE *f = pack_fopen(filename, F_WRITE);
   int ret = TRUE;

   if (!f)
      return FALSE;
   
   if (
      pack_fwrite(dat->dat, dat->size, f)
   < dat->size)
      ret = FALSE;
   
   pack_fclose(f);

   return ret;
}


static DATAFILE *grab_alflac(int type, AL_CONST char *filename, DATAFILE_PROPERTY **prop, int depth)
{
/* this is grab_binary */
   void *mem;
   long sz = file_size(filename);
   PACKFILE *f;

   if (sz <= 0)
      return NULL;

   mem = malloc(sz);

   f = pack_fopen(filename, F_READ);
   if (!f) {
      free(mem);
      return NULL; 
   }

   if (pack_fread(mem, sz, f) < sz) {
      pack_fclose(f);
      free(mem);
      return NULL;
   }

   pack_fclose(f);

   return datedit_construct(type, mem, sz, prop);
}


/* plugin interface header */
DATEDIT_OBJECT_INFO datalflac_info =
{
   DAT_ID('F', 'L', 'A', 'W'),
   "FLAC/FLAW Sample", 
   NULL,
   makenew_alflac,
   save_alflac_in_datafile,
   plot_alflac,
   NULL,
   NULL
};



DATEDIT_GRABBER_INFO datalflac_grabber =
{
   DAT_ID('F', 'L', 'A', 'W'),
   "flac",
   "flac",
   grab_alflac,
   export_alflac,
   NULL
};


 
 
 /************************************** menu / convert stuff **/
/* exports a sample into an external file */
static int export_sample_alflac(AL_CONST DATAFILE *dat, AL_CONST char *filename)
{
   SAMPLE *spl = (SAMPLE *)dat->dat;
   int bps = spl->bits/8 * ((spl->stereo) ? 2 : 1);
   int len = spl->len * bps;
   int i;
   int16_t s;
   PACKFILE *f;

   errno = 0;
   
   f = pack_fopen(filename, F_WRITE);

   if (f) {
      pack_fputs("RIFF", f);                 /* RIFF header */
      pack_iputl(36+len, f);                 /* size of RIFF chunk */
      pack_fputs("WAVE", f);                 /* WAV definition */
      pack_fputs("fmt ", f);                 /* format chunk */
      pack_iputl(16, f);                     /* size of format chunk */
      pack_iputw(1, f);                      /* PCM data */
      pack_iputw((spl->stereo) ? 2 : 1, f);  /* mono/stereo data */
      pack_iputl(spl->freq, f);              /* sample frequency */
      pack_iputl(spl->freq*bps, f);          /* avg. bytes per sec */
      pack_iputw(bps, f);                    /* block alignment */
      pack_iputw(spl->bits, f);              /* bits per sample */
      pack_fputs("data", f);                 /* data chunk */
      pack_iputl(len, f);                    /* actual data length */

      if (spl->bits == 8) {
	 pack_fwrite(spl->data, len, f);     /* write the data */
      }
      else {
	 for (i=0; i < (int)spl->len * ((spl->stereo) ? 2 : 1); i++) {
	    s = ((int16_t *)spl->data)[i];
	    pack_iputw(s^0x8000, f);
	 }
      }

      pack_fclose(f);
   }

   return (errno == 0);
}


/* worker function for changing the type of an image */
static int do_to_flac_flaw(DATAFILE *dat, int *param, int type)
{
   char *data = NULL;
   long sz;
   
   char *file_wav = "alflac_temp_file.wav";
   char *file_flac = "alflac_temp_file.flac";
   char *main_command = "flac -e --best --lax --verify alflac_temp_file.wav -o alflac_temp_file.flac";
   char *test_command = "flac --test alflac_temp_file.flac";
   
   if ((dat->type != DAT_SAMPLE)) {
      return D_O_K;
   }

   if (dat->type == type)
      return D_O_K;

   /* create .wav */
   export_sample_alflac(dat, file_wav);
   
   /* wav -> flac */
   if (
      system(NULL) == 0
   ||
      system(main_command) != 0
   ||
      exists(file_flac) != TRUE
   ) {
      /* FAILED */
      goto error;
   }
   
   /* CHECK */
   if (
      system(test_command) != 0
   ) {
      goto error;
   }
   
   /* read .flac */
   {
      PACKFILE *pf;
      
      sz = file_size(file_flac);
      if (sz <= 8)
         goto error;
      
      data = malloc(sz * sizeof(char));
      if (!data)
         goto error;
      
      pf = pack_fopen(file_flac, F_READ);
      if (
         pack_fread(data, sz, pf)
      < sz) {
         pack_fclose(pf);
         goto error;
      }
      pack_fclose(pf);
   }
   
   /* OK */
   destroy_sample(dat->dat);
   dat->dat = data; data = NULL;
   dat->size = sz;
   dat->type = type;
   
   /* clean up */
   goto clean;
   
error:
   (*param)++;
   
clean:
   if (data)
      free(data);
   
   delete_file(file_wav);
   delete_file(file_flac);

   return D_REDRAW;
}


static int to_flac_flaw(void)
{
   int type = DAT_ID('F', 'L', 'A', 'W');
   char buf[80];
   int ret, n;
   int p = 0;
   
   rectfill(screen, SCREEN_W/2 - 60, SCREEN_H/2 - 30, SCREEN_W/2 + 60, SCREEN_H/2 + 30, gui_bg_color);
   rect    (screen, SCREEN_W/2 - 60, SCREEN_H/2 - 30, SCREEN_W/2 + 60, SCREEN_H/2 + 30, gui_fg_color);
   textprintf_centre_ex(screen, font, SCREEN_W/2, SCREEN_H/2, gui_fg_color, -1, "WAIT");
   
   ret = grabber_foreach_selection(do_to_flac_flaw, &n, &p, type);

   if (n <= 0) {
      alert ("Nothing to change!", NULL, NULL, "OK", NULL, 13, 0);
   }
   else if (p > 0) {
      sprintf(buf, "Failed for %d object(s)", p);
      alert(buf, NULL, NULL, "OK", NULL, 13, 0);
   }

   if (n > p) {
      grabber_modified(TRUE);
      grabber_rebuild_list(NULL, FALSE);
   }

   return ret;
}



/* worker function for counting bitmap objects */
static int alflac_change_q_do(DATAFILE *dat, int *param, int param2)
{
   if ((dat->type == DAT_SAMPLE)) 
      (*param)++;

   return D_O_K;
}



/* checks whether our image changing commands are allowed at the moment */
static int alflac_change_query(int popup)
{
   int n, p;

   if (popup) {
      p = 0;
      grabber_foreach_selection(alflac_change_q_do, &p, &n, 0);
      return (p > 0);
   }

   return TRUE;
}



static MENU alflac_menu =
{
   "Convert to FLAC/FLAW",
   to_flac_flaw,
   NULL,
   0,
   NULL
};

DATEDIT_MENU_INFO alflac_menu_info =
{
   &alflac_menu,
   alflac_change_query,
   DATEDIT_MENU_OBJECT | DATEDIT_MENU_POPUP,
   0,
   NULL
};

