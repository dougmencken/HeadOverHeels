/* ALFLAC - libFLAC for Allegro
 * Copyright (C) 2006, David Batley, CompuNach
 *
 * This code is avaliable for distribution under the Xiph License (below).
 *
 * You may also distribute the code below under the GNU General Public
 * License (GPL).
 * 
 * Xiph (BSD-style) License
 * ========================
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * - Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 *
 * - Neither the name of the Xiph.org Foundation nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE FOUNDATION OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
 
#include <alflac/_internal.h>


/* global data (from _options.h) */

const char *alflac_id = ALFLAC_NAME_VER;
const int alflac_version[4] = {  ALFLAC_VER_MAJ, ALFLAC_VER_MIN, ALFLAC_VER_SUB, ALFLAC_VER_BUILD };
const char *alflac_id_copyright = ALFLAC_INFO_COPYRIGHT;
const char *alflac_id_contact = ALFLAC_INFO_CONTACT;
const char *alflac_id_authors = ALFLAC_INFO_AUTHORS;


/* prototype */
int alflac_poll_ex(ALFLAC *af, int to_end_of_stream);



/* functions */

ALFLAC *alflac_alflac_new(){
   /* alflac_alflac_new
      creates and sets up a new ALFLAC structure
   */
   
   ALFLAC *af;
   
   af = malloc(sizeof(ALFLAC));
   if (!af)
      return NULL;
   
   af->flac = alflac_flac_new(af);
   
   af->source = alflac_destination_new(1);
   af->destination = alflac_destination_new(0);
   
   af->info = NULL;
   
   return af;
}

void alflac_alflac_del(ALFLAC *af){
   /* alflac_alflac_del
      deletes an ALFLAC and everything in it
   */
   
   if (!af)
      return;
   
   alflac_flac_del(af->flac);
   alflac_destination_del(af->source);
   alflac_destination_del(af->destination);
   alflac_info_del(af->info);
   
   free(af);
}

int alflac_poll(ALFLAC *af){
   return alflac_poll_ex(af, 0);
}
   
int alflac_poll_all(ALFLAC *af){
   int r;
   do {
      r = alflac_poll_ex(af, 1);
   } while (r > 0);

   return r;
}

int alflac_poll_ex(ALFLAC *af, int to_end_of_stream){
   /*
   Call this regular, like.
   
   Set "to_end_of_stream" as
      ZERO     to do one frame at a time (a good idea)
      NONZERO  to do all the frames (a bad idea, and it may take a while)
   Even if you set "to_end_of_stream" to nonzero, you should really
   still loop over this function.
   
   Returns  NEGATIVE    on error
            ZERO        if END OF STREAM
            1           if we didn't call FLAC (but stuff may still have been done)
            2           if we called FLAC
   */
   int temp;
   
   if (!af)
      return -1;
   
   /*
   Does the read device have data to give?
   */
   temp = alflac_destination_ready_for_data_read(af->source);
   if (temp == 0) {
      /*
      Device is not ready to give data (so return "nothing to do")
      */
      return 1;
   } else if (temp < 0) {
      alflac_error_god("destination reports failure");
      return temp;
   }
   
   /*
   Does the write device need more data?
   */
   temp = alflac_destination_ready_for_data_write(af->destination);
   if (temp == 0) {
      /*
      Device does not need (or want) more data (so return "nothing to do")
      */
      return 1;
   } else if (temp < 0) {
      alflac_error_god("source reports failure");
      return temp;
   }
   
   /*
   At this point, more data is required from FLAC. But if
   at end of stream, theres no more to be had! Fix things up
   as needed, and return "end of stream"
   */
   if (af->flac->reached_end_of_stream) {
      alflac_destination_end_of_stream(af->destination);
      return 0; /* end of stream */
   }
   
   /*
   decode data with FLAC
   */
   temp = alflac_flac_process(af->flac, to_end_of_stream);
   if (temp > 0) {
      /*
      That's all we'll get from FLAC. We'll still need to use up
      the stuff we just got, so still return "we did stuff"
      */
      af->flac->reached_end_of_stream = 1;
   } else if (temp < 0) {
      alflac_error_god("alflac_flac_process failed");
      return temp; /* error */
   }
   
   /*
   return "we did stuff"
   */
   return 2;
}



