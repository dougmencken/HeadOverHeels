/* ALFLAC - libFLAC for Allegro
 * Copyright (C) 2006, David Batley, CompuNach
 *
 * This code is avaliable for distribution under the Xiph License (below).
 *
 * You may also distribute the code below under the GNU General Public
 * License (GPL).
 * 
 * Xiph (BSD-style) License
 * ========================
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * - Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 *
 * - Neither the name of the Xiph.org Foundation nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE FOUNDATION OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include <alflac/_internal.h>

ALFLAC_AUDIOSTREAM *alflac_audiostream_new(af_uint buffer_size){
   /*
   Creates a new ALFLAC_AUDIOSTREAM ready for an allegro AUDIOSTREAM
   */
   
   ALFLAC_AUDIOSTREAM *a = malloc(sizeof(ALFLAC_AUDIOSTREAM));
   if (!a)
      return NULL;
   
   a->buffer_size = buffer_size;
   a->audiostream = NULL;
   a->buffer = NULL;
   a->overflow = NULL;
   
   return a;
}

void alflac_audiostream_del(ALFLAC_AUDIOSTREAM *a){
   if (!a)
      return;
   
   if (a->audiostream)
      stop_audio_stream(a->audiostream);
   
   free(a);
}

int alflac_audiostream_start_play(ALFLAC_AUDIOSTREAM *a, ALFLAC_INFO *info, af_uint frame_size){
   /*
   Sets up a new AUDIOSTREAM from allegro
   */
   if (!a || !info || !frame_size)
      return 12;
   
   a->audiostream = play_audio_stream(
      (a->buffer_size / frame_size),
         /* length argument is size of buffer in allegro audio frames. */
      info->bits,
      (info->channels==2)?1:0,
      info->frequency,
      255,
      127
   );
   
   if (!a->audiostream) {
      return 17;
   }
   
   /* setup buffer too */
   alflac_audiostream_make_buffer(a);
   
   return 0;
}

int alflac_audiostream_process(ALFLAC_AUDIOSTREAM *a){
   /*
   gets a buffer, if required.
   
   Returns  ZERO        If no need to fill buffer
            POSITIVE    If buffer needs to be filled from FLAC
            NEGATIVE    On error
            
   These return values must be the same as for
   alflac_destination_ready_for_data_*
   */
   if (!a)
      return -1;
   
   /* not started */
   if (!a->audiostream)
      return 1; /* fill */
   
   
   /* there is no buffer to fill */
   if (a->buffer == NULL) {
      
      /* get a buffer */
      alflac_audiostream_make_buffer(a);
         
      /* buffer not made */
      if (a->buffer == NULL) {
      
         /* Allegro doesn't need data */
         return 0;
      }
   }
   
   /*
   at this point, there should be a valid a->buffer
   */
   
   /* there is an overflow */
   if (a->overflow != NULL) {
      
      /* data from overflow -> buffer */
      if (
         alflac_buffer_fill_from(a->buffer, a->overflow, 0)
      < 0) {
         alflac_error_god("overflow -> buffer death");
         return -25;
      }
      
      /* emptied overflow ? */
      if ( alflac_buffer_is_read_to_end(a->overflow) ) {
         
         /* overflow empty (delete) */
         alflac_buffer_del( a->overflow );
         a->overflow = NULL;
         
      }
      
      /* filled_buffer */
      if ( alflac_buffer_is_full(a->buffer) ) {
      
         /* send buffer to allegro */
         alflac_audiostream_free_buffer(a);
         
         /* no buffer is left to fill (it went to allegro) */
         return 0;
      }
      
   }
   
   /*
   at this point, overflow doesn't exist, and buffer still has
   space in it
   This space should be filled from FLAC.
   */
   return 1;
}

void alflac_audiostream_make_buffer(ALFLAC_AUDIOSTREAM *a) {
   /*
   Asks allegro for a buffer
   */
   af_byte *data;
   
   if (a == NULL || a->buffer != NULL || a->audiostream == NULL)
      return;
   
   /* allegro call: */
   data = get_audio_stream_buffer(a->audiostream);
   if (!data)
      return; /* no need for data */
   
   a->buffer = alflac_buffer_from_data(data, a->buffer_size);
}


void alflac_audiostream_free_buffer(ALFLAC_AUDIOSTREAM *a) {
   /*
   sends buffer to allegro
   */
   af_byte *data;
   af_uint size;
   
   if (a == NULL || a->buffer == NULL)
      return;
   
   /* this deletes the ALFLAC_BUFFER, just leaving the data on "data" */
   alflac_buffer_to_data(&(a->buffer), &data, &size);

   /* allegro call: */
   free_audio_stream_buffer(a->audiostream);
}

