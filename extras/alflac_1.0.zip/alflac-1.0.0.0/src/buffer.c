/* ALFLAC - libFLAC for Allegro
 * Copyright (C) 2006, David Batley, CompuNach
 *
 * This code is avaliable for distribution under the Xiph License (below).
 *
 * You may also distribute the code below under the GNU General Public
 * License (GPL).
 * 
 * Xiph (BSD-style) License
 * ========================
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * - Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 *
 * - Neither the name of the Xiph.org Foundation nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE FOUNDATION OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include <alflac/_internal.h>


ALFLAC_BUFFER *alflac_buffer_new(af_uint size){
   /*
   creates and returns a new ALFLAC_BUFFER of size "size"
   (or NULL on error).
   */
   ALFLAC_BUFFER *b = malloc(sizeof(ALFLAC_BUFFER));
   if (!b)
      return NULL;
   
   b->read_position = b->write_position = 0;
   if (size >= 0) {
      b->data = malloc (size * sizeof(af_byte));
      b->size = size;
      if (!b->data) {
         free(b);
         return NULL;
      }
   } else {
      b->data = NULL;
      b->size = 0;
   }
   return b;
}


void alflac_buffer_del(ALFLAC_BUFFER *b){
   /*
   frees "b"
   */
   if (!b)
      return;
   
   if (b->data)
      free(b->data);
   
   free(b);
}


void alflac_buffer_to_data(ALFLAC_BUFFER **buf, af_byte **data, af_uint *size){
   /*
   Destroys an ALFLAC_BUFFER ("buf") but not the data it contains.
   
   If data and size are not NULL, they will be set to the data and size
   of the data held in the buffer.
   
   This is similar to 'alflac_buffer_divorce_data', except that the
   "buf" is deleted.
   */

   af_byte *data_int; af_uint size_int;
   
   /* dummy values if data/size is NULL. */
   if (!data)
      data = &data_int;
   if (!size)
      size = &size_int;
   
   /* no buf? */   
   if (*buf == NULL) {
      *data = NULL;
      *size = 0;
      return;
   }
   
   *data = (*buf)->data;
   *size = (*buf)->size;
   
   free(*buf);
   *buf = NULL;
}

void alflac_buffer_divorce_data(ALFLAC_BUFFER *buf, af_byte **data, af_uint *size){
   /*
   Resets "buf" to zero size, placing all the buffer's data on "data"
   and "size". This gives all the data, ignoring read_position and
   write_position.
   
   If data and size is NULL, they're not filled.
   
   This is similar to 'alflac_buffer_to_data', except that the buffer
   still remains.
   */
   
   af_byte *data_int; af_uint size_int;
   
   /* dummy values if data/size is NULL. */
   if (!data)
      data = &data_int;
   if (!size)
      size = &size_int;
   
   /* ASSERT buf */
   if (!buf) {
      *data = NULL;
      *size = 0;
      return;
   }
   
   *data = buf->data;
   *size = buf->size;
   
   buf->data = NULL;
   buf->size = 0;
   
   buf->read_position = 0;
   buf->write_position = 0;
}


int alflac_buffer_resize(ALFLAC_BUFFER *buf, af_uint size){
   /*
   Resizes "buf" to "size"
   Returns  NEGATIVE on error
            ZERO     on success.
            ONE      if size is smaller (won't go smaller)
   */
   
   af_byte *newbufdata;
   
   if (size < buf->size)
      return 1;
   
   newbufdata = realloc(buf->data, size);
   
   if (!newbufdata)
      return -64;
   
   /* ok */
   buf->data = newbufdata;
   buf->size = size;
   return 0;
}

int alflac_buffer_fill_resize(ALFLAC_BUFFER *buf, af_byte *data, af_uint size){
   /*
   copies "size" bytes from "data" to "buf", increasing "buf" as required.
   Note, this doesn't reduce the size of "buf" (ever).
   
   Returns NEGATIVE on success
           zero or positive on error.
   */
   af_uint totalsize;
   
   /* write pos can't be off edge of buffer */
   if (buf->write_position > buf->size)
      buf->write_position = buf->size;
   if (buf->write_position < 0)
      buf->write_position = 0;
   
   /* resize required */
   totalsize = size + buf->write_position;
   if (totalsize > buf->size) {
      af_byte *newbufdata = realloc(buf->data, totalsize);
      if (!newbufdata)
         return 0;
      buf->data = newbufdata;
   }   
   
   memcpy(buf->data + buf->write_position, data, size);
   
   return -1;
}

int alflac_buffer_fill(ALFLAC_BUFFER *buf, af_byte *data, af_uint size){
   /*
   copies "size" bytes from "data" to "buf".
   
   Returns negative on success
            the number of bytes actually copied if there's not enough space
            zero on error or if no data was copied.
   */
   af_uint rsize = MIN(size, buf->size - buf->write_position);
   if (rsize <= 0)
      return 0;
   
   memcpy(buf->data + buf->write_position, data, rsize);
   
   return (rsize == size) ? (-1) : (rsize);
}


ALFLAC_BUFFER *alflac_buffer_fill_overflow(ALFLAC_BUFFER *buf, af_byte *data, af_uint size){
   /*
   copies "size" bytes to buffer "buf".
   If the data won't fit, it creates a new ALFLAC_BUFFER (an overflow buffer) and copies
   the remaining data there.
   Returns the overflow buffer, if there was an overflow; else NULL.
   */
   af_uint copied_ok=0;
   ALFLAC_BUFFER *overflow;
   
   copied_ok = alflac_buffer_fill(buf, data, size);
   if (copied_ok < 0)
      return NULL;
      
   overflow = alflac_buffer_new(size - copied_ok);
   if (!overflow)
      return NULL;
   
   alflac_buffer_fill(overflow, data + copied_ok, size - copied_ok);
      
   return overflow;
}


int alflac_buffer_read(ALFLAC_BUFFER *buf, af_byte *data, af_uint *size){
   /*
   Fills buffer "data" with up to "size" bytes of data read from the buffer.
   On exit "size" is the size of the data copied to "data".
   
   Returns 0         Is OK
           1         Is end of stream
           Negative  on error
   */
   
   af_uint orig = *size;
   
   /* errors */
   if (!buf || !data || !size || (*size) <= 0) {
      return -1;
   }
   
   /* nothing to copy */
   if (buf->read_position >= buf->size || *size == 0) {
      *size = 0;
      return 1;
   }
   
   /* reduce to size of buffer if too big. */
   *size = MIN(*size, buf->size - buf->read_position);
   
   /* copy */
   memcpy(data, buf->data + buf->read_position, *size);
   buf->read_position += *size;
   
   return (orig == *size) ? 0 : 1;
}


af_bool alflac_buffer_is_read_to_end(ALFLAC_BUFFER *buf){
   if (!buf)
      return 1;
   
   return (buf->read_position >= buf->size) ? 1 : 0;
}

af_bool alflac_buffer_is_full(ALFLAC_BUFFER *buf){
   if (!buf)
      return 1;
   
   return (buf->write_position >= buf->size) ? 1 : 0;
}


int alflac_buffer_fill_from(ALFLAC_BUFFER *dest, ALFLAC_BUFFER *source, af_uint max) {
   /*
   copies at most "max" bytes from source to dest, updating the read_position and
   write_position on each
   "max" can be zero to copy all that either can handle.
   Returns number of bytes copied
           or negative on error
   */
   af_uint size;
   
   if (!dest || !source)
      return -2;
   
   /* limit by size avaliable */
   size = MIN ( dest->size - dest->write_position , source->size - source->read_position );
   if (size < 0)
      return -3;
   
   /* limit by "max" */
   if (max != 0 && max < size)
      size = max;
   
   /* nothing to write */
   if (size == 0)
      return 0;
      
   memcpy(
      dest->data + dest->write_position,
      source->data + source->read_position,
      size
   );
   dest->write_position += size;
   source->read_position += size;
   
   return size;
}


ALFLAC_BUFFER *alflac_buffer_from_data(af_byte *data, af_uint size){
   /*
   creates an ALFLAC_BUFFER from "data", destroying "data".
   */
   ALFLAC_BUFFER *buf = alflac_buffer_new(0);
   buf->data = data;
   buf->size = size;
   return buf;
}






