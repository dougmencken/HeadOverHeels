/* ALFLAC - libFLAC for Allegro
 * Copyright (C) 2006, David Batley, CompuNach
 *
 * This code is avaliable for distribution under the Xiph License (below).
 *
 * You may also distribute the code below under the GNU General Public
 * License (GPL).
 * 
 * Xiph (BSD-style) License
 * ========================
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * - Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 *
 * - Neither the name of the Xiph.org Foundation nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE FOUNDATION OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include <FLAC/all.h>
#include <alflac/_internal.h>


/* local proto */
int alflac_callback_write_to_destination (
   const FLAC__Frame          *  frame,
   const FLAC__int32 * const buffer[],
   ALFLAC_DESTINATION         *  destination,
   ALFLAC                     *  af
) ;

int alflac_fill_buffer_then_overflow (
   const FLAC__Frame          *  frame,
   const FLAC__int32 * const flac_buffer[],
   ALFLAC_DESTINATION         *  dest,
   ALFLAC_BUFFER              *  out_buffer,
   ALFLAC_BUFFER              ** overflow
) ;

int alflac_fill_buffer_then_overflow_ex(
   const FLAC__int32 *           data0,
   const FLAC__int32 *           data1,
   af_uint                       total_frames,
   ALFLAC_FILL_FUNCTION       *  fill_function,
   af_uint                       bytes_per_frame,
   ALFLAC_BUFFER              *  buffer,
   ALFLAC_BUFFER              ** overflow
) ;



/* functions */

void alflac_callback_metadata(
   const FLAC__StreamDecoder *decoder,
   const FLAC__StreamMetadata *metadata,
   void *client_data
) {
   /* empty */
   (void) client_data;
   (void) metadata;
   (void) decoder;
}

void alflac_callback_error(
   const FLAC__StreamDecoder *decoder,
   FLAC__StreamDecoderErrorStatus status,
   void *client_data
) {
   /* empty */
   (void) client_data;
   (void) status;
   (void) decoder;
   
   alflac_error_god("libFLAC reports error");
}


FLAC__StreamDecoderReadStatus alflac_callback_read(
   const FLAC__StreamDecoder *decoder,
   FLAC__byte buffer[],
   unsigned *bytes,
   void *client_data
) {
   ALFLAC *af = (ALFLAC *) client_data;
   
   if (!af || !af->source)
      return FLAC__STREAM_DECODER_READ_STATUS_ABORT;
   
   switch (af->source->type) {
      case ALFLAC_DESTINATION_TYPE_PACKFILE:
      {
         PACKFILE *p = (PACKFILE *) af->source->data;
         
         if (p == NULL) {
            *bytes = 0;
            alflac_error_god("No Packfile");
            return FLAC__STREAM_DECODER_READ_STATUS_END_OF_STREAM;
         }
         
         if (pack_feof(p)){
            *bytes = 0;
            return FLAC__STREAM_DECODER_READ_STATUS_END_OF_STREAM;
         }
         
         *bytes = pack_fread(buffer, (*bytes) * (sizeof(FLAC__byte)), p);
         
         if (*bytes <= 0){
            *bytes = 0;
            return FLAC__STREAM_DECODER_READ_STATUS_ABORT;
         }
         break;
      }
      
      case ALFLAC_DESTINATION_TYPE_FILE:
      {
         FILE *fp = (FILE *) af->source->data;
         
         if (fp == NULL) {
            *bytes = 0;
            alflac_error_god("No File");
            return FLAC__STREAM_DECODER_READ_STATUS_END_OF_STREAM;
         }
         
         if (feof(fp)){
            *bytes = 0;
            return FLAC__STREAM_DECODER_READ_STATUS_END_OF_STREAM;
         }
         
         *bytes = fread(buffer, sizeof(FLAC__byte), *bytes, fp);
         
         if (*bytes <= 0){
            *bytes = 0;
            return FLAC__STREAM_DECODER_READ_STATUS_ABORT;
         }
         break;
      }
      
      case ALFLAC_DESTINATION_TYPE_MEMORY_BUFFER:
      case ALFLAC_DESTINATION_TYPE_BORROW_DATAFILE:
      {
         ALFLAC_BUFFER *buf;
         int r;
         
         buf = (ALFLAC_BUFFER *) af->source->data;
         r = alflac_buffer_read(buf, buffer, bytes);
         
         if (r < 0) /* error */
            return FLAC__STREAM_DECODER_READ_STATUS_ABORT;
         if (r == 1) /* end of stream */
            return FLAC__STREAM_DECODER_READ_STATUS_END_OF_STREAM;
         break;
      }
      
      case ALFLAC_DESTINATION_TYPE_AUDIOSTREAM:
      case ALFLAC_DESTINATION_TYPE_NOTHING:
      case ALFLAC_DESTINATION_TYPE_DUPLICATE:
      case ALFLAC_DESTINATION_TYPE_CONSOLE:
      default:
      {
         *bytes = 0;
         alflac_error_god("Bad source");
         return FLAC__STREAM_DECODER_READ_STATUS_END_OF_STREAM;
      }
   }
   return FLAC__STREAM_DECODER_READ_STATUS_CONTINUE;
}


FLAC__StreamDecoderWriteStatus alflac_callback_write(
   const FLAC__StreamDecoder *decoder,
   const FLAC__Frame *frame,
   const FLAC__int32 * const buffer[],
   void *client_data
) {
   ALFLAC *af = (ALFLAC *) client_data;
   
   if (!af || !af->destination)
      return FLAC__STREAM_DECODER_WRITE_STATUS_ABORT;
   
   if (af->info == NULL) {
      alflac_info_set(
         af,
         frame->header.channels,
         frame->header.bits_per_sample,
         frame->header.sample_rate
      );
   }
   
   if (
      alflac_callback_write_to_destination (
         frame,
         buffer,
         af->destination,
         af
      )
   != 0)
      return FLAC__STREAM_DECODER_WRITE_STATUS_ABORT;
   
   return FLAC__STREAM_DECODER_WRITE_STATUS_CONTINUE;
}


int alflac_callback_write_to_destination (
   const FLAC__Frame          *  frame,
   const FLAC__int32 * const buffer[],
   ALFLAC_DESTINATION         *  destination,
   ALFLAC                     *  af
) {
   /*
   returns nonzero on error
   */
   
   if (!destination) {
      /* others assumed to be there from function above checks */
      alflac_error_god("no destination");
      return 1;
   }
   
   switch (destination->type){
      case ALFLAC_DESTINATION_TYPE_AUDIOSTREAM:
      {
         ALFLAC_AUDIOSTREAM *a = (ALFLAC_AUDIOSTREAM *) destination->data;
         
         if (!a) {
            alflac_error_god("No ALFLAC_AUDIOSTREAM set up");
            return 1;
         }
         
         if (a->audiostream == NULL) {
            /* 1st time - start play */
            if (
               alflac_audiostream_start_play(a, af->info, destination->fill_function->output_frame_size)
            != 0) {
               alflac_error_god("Can't start allegro audiostream play");
               return 1;
            }
         }
         
         if (
            alflac_fill_buffer_then_overflow ( frame, buffer, destination,
               a->buffer,
               & (a->overflow)
            )
         != 0) {
            alflac_error_god("audiostream: bad fill");
            return 1;
         }
         
         /* OK! */
         /* send to allegro? */
         if ( a->buffer && alflac_buffer_is_full(a->buffer) ) {
            alflac_audiostream_free_buffer(a);
         }
         return 0;
      }
      
      case ALFLAC_DESTINATION_TYPE_DUPLICATE:
      {
         if (
            alflac_callback_write_to_destination (
               frame,
               buffer,
               destination->duplicate_destination_1,
               af
            )
          != 0)
             return 1;
         if (
            alflac_callback_write_to_destination (
               frame,
               buffer,
               destination->duplicate_destination_2,
               af
            )
         != 0)
            return 2;
         return 0;
      }
      
      case ALFLAC_DESTINATION_TYPE_MEMORY_BUFFER:
      {
         ALFLAC_BUFFER *membuf = (ALFLAC_BUFFER *) destination->data;
         
         if (membuf == NULL) {
            alflac_error_god("dest: no memory buffer");
            return 1;
         }
         
         if (
            alflac_fill_buffer_then_overflow ( frame, buffer, destination,
               membuf,
               NULL
            )
         != 0) {
            alflac_error_god("mem buffer: bad fill");
            return 1;
         }
         
         return 0;
      }

      case ALFLAC_DESTINATION_TYPE_NOTHING:
      {
         /* trash it */
         return 0;
      }
      
      case ALFLAC_DESTINATION_TYPE_FILE:
      case ALFLAC_DESTINATION_TYPE_CONSOLE:
      {
         ALFLAC_BUFFER *buf;
         FILE *fp;
         
         if (destination->type == ALFLAC_DESTINATION_TYPE_CONSOLE)
            fp = stdout;
         else
            fp = (FILE *) destination->data;
         
         if (fp == NULL) 
            return 1;
         
         buf = alflac_buffer_new(0);
         
         if (
            alflac_fill_buffer_then_overflow ( frame, buffer, destination,
               buf,
               NULL
            )
         != 0) {
            alflac_error_god("file: bad fill");
            return 1;
         }
         
         if (
            fwrite(buf->data, sizeof(af_byte), buf->size, fp)
         < buf->size) {
            alflac_error_god("can't write to file");
            alflac_buffer_del(buf);
            return 1;
         }
         
         alflac_buffer_del(buf);
         return 0;
      }
      
      case ALFLAC_DESTINATION_TYPE_PACKFILE:
      {
         ALFLAC_BUFFER *buf;
         PACKFILE *pf;
         
         pf = (PACKFILE *) destination->data;
         if (pf == NULL) 
            return 1;
         
         buf = alflac_buffer_new(0);
         
         if (
            alflac_fill_buffer_then_overflow ( frame, buffer, destination,
               buf,
               NULL
            )
         != 0) {
            alflac_error_god("packfile: bad fill");
            return 1;
         }
         
         if (
            pack_fwrite(buf->data, buf->size, pf)
         < buf->size) {
            alflac_error_god("can't write to packfile");
            alflac_buffer_del(buf);
            return 1;
         }
         
         alflac_buffer_del(buf);
         return 0;
      }
      
      default:
      {
         alflac_error_god("Bad destination");
         return 1;
      }
   }
   
   
   return 0;
}


int alflac_fill_buffer_then_overflow (
   const FLAC__Frame          *  frame,
   const FLAC__int32 * const flac_buffer[],
   ALFLAC_DESTINATION         *  dest,
   ALFLAC_BUFFER              *  out_buffer,
   ALFLAC_BUFFER              ** overflow
) {
   /*
   Calls alflac_fill_buffer_then_overflow_ex with default values.
   
   Copies FLAC data from "data" to "buffer", overspilling onto "overflow"
   
   Overflow will be created if needed, and it's location put onto "overflow" (hence
   the double pointer).
   
   If "overflow" is NULL, "buffer" will be enlarged. Don't do that for Allegro as
   the ALFLAC_BUFFER for that must not be resized.
   
   The fill function will be taken from "dest".
   
   Returns  ZERO     On success
            NONZERO  On error
   */
   
   return alflac_fill_buffer_then_overflow_ex(
      flac_buffer[0],
         /* left or mono buffer */
      (frame->header.channels >= 2) ? (flac_buffer[1]) : (flac_buffer[0]),
         /* right buffer (or buffer 0 for mono) */
      frame->header.blocksize,
         /* number of frames in buffer[0] */
      dest->fill_function->fill_function,
         /* func to use */
      dest->fill_function->output_frame_size,
         /* bytes per allegro audio frame */
      out_buffer,
         /* destination buffer */
      overflow
         /* location for new overflow buffer */
   );
}

int alflac_fill_buffer_then_overflow_ex(
   const FLAC__int32 *           data0,
   const FLAC__int32 *           data1,
   af_uint                       total_frames,
   ALFLAC_FILL_FUNCTION       *  fill_function,
   af_uint                       bytes_per_frame,
   ALFLAC_BUFFER              *  buffer,
   ALFLAC_BUFFER              ** overflow
) {
   /*
   Copies FLAC data from "data" to "buffer", overspilling onto "overflow"
   
   Overflow will be created if needed, and it's location put onto "overflow" (hence
   the double pointer).
   
   If "overflow" is NULL, "buffer" will be enlarged. Don't do that for Allegro as
   the ALFLAC_BUFFER for that must not be resized.
   
   You should normally call alflac_fill_buffer_then_overflow unless you want to
   do something stupid.
   
   Returns  ZERO     On success
            NONZERO  On error
   */
   
   af_uint buffer_copy_frames   = 0;
   af_uint overflow_copy_frames = 0;
      /* The size, in FRAMES, of the data to be copied */
   af_uint frame = 0;
      /* current frame being processed */
   af_byte *tempbuf = NULL;
   
   if (!fill_function || !buffer || !data0 || !total_frames || !bytes_per_frame) {
      alflac_error_god("Variable required: %s%s%s%s%s",
         (!fill_function)?"fill ":"",
         (!buffer)?"buffer ":"",
         (!data0)?"data ":"",
         (!total_frames)?"total ":"",
         (!bytes_per_frame)?"bytes_per_frame ":"" );
      return -13;
   }
   
   if (!data1)
      data1=data0;
      
   if (overflow) {
      /* you should NOT have an overflow assigned already. */
      if (*overflow != NULL) {
         alflac_error_god("You should not setup an overflow yourself. Provide a pointer to NULL.");
         return 17;
      }
      
      /* set max frames for buffer */
      buffer_copy_frames = (buffer->size - buffer->write_position) / bytes_per_frame;
      if (buffer_copy_frames > total_frames)
         buffer_copy_frames = total_frames;
      
      /* overflow rest */
      overflow_copy_frames = total_frames - buffer_copy_frames;
      
      /* alloc the overflow buffer */
      if (overflow_copy_frames) {
         *overflow = alflac_buffer_new(overflow_copy_frames * bytes_per_frame);
         if (! (*overflow) ) {
            alflac_error_god("Memory error (for overflow)");
            return 74;
         }
      }
      
   } else {
      
      /* resize */
      buffer_copy_frames = total_frames;
      overflow_copy_frames = 0;
      if (
         alflac_buffer_resize(buffer, (buffer_copy_frames * bytes_per_frame) + buffer->write_position)
      < 0) { /* error */
         alflac_error_god("Failed to resize buffer");
         return 18;
      }
      
   }
   
   /* copy to buffer */
   
      tempbuf = buffer->data + buffer->write_position;
      buffer->write_position += bytes_per_frame * buffer_copy_frames;
      for (frame = 0; frame < buffer_copy_frames; frame ++){
         fill_function(
            tempbuf,
            data0[frame],
            data1[frame]
         );
         tempbuf += bytes_per_frame;
      }
   
   /* copy to overflow */
   if (overflow && overflow_copy_frames) {
   
      tempbuf = (*overflow)->data + (*overflow)->write_position;
      (*overflow)->write_position += bytes_per_frame * overflow_copy_frames;
      for (; frame < total_frames; frame ++){
         fill_function(
            tempbuf,
            data0[frame],
            data1[frame]
         );
         tempbuf += bytes_per_frame;
      }
   }
   
   return 0;
}

