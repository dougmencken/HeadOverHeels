/* ALFLAC - libFLAC for Allegro
 * Copyright (C) 2006, David Batley, CompuNach
 *
 * This code is avaliable for distribution under the Xiph License (below).
 *
 * You may also distribute the code below under the GNU General Public
 * License (GPL).
 * 
 * Xiph (BSD-style) License
 * ========================
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * - Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 *
 * - Neither the name of the Xiph.org Foundation nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE FOUNDATION OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include <alflac/_internal.h>


void alflac_destination_close(ALFLAC_DESTINATION *d);


/* functions */
ALFLAC_DESTINATION *alflac_destination_new(af_bool is_source){
   /*
   creates a new ALFLAC_DESTINATION to do nothing with.
   Call alflac_destination_set_* to actually do stuff.
   */
   ALFLAC_DESTINATION *d = malloc(sizeof(ALFLAC_DESTINATION));
   
   if (!d)
      return NULL;
   
   d->fill_function = malloc(sizeof(ALFLAC_DESTINATION_FILL_FUNCTION));
   if (!d->fill_function) {
      free(d); return NULL;
   }
   
   d->type = ALFLAC_DESTINATION_TYPE_NOTHING;
   d->is_source = is_source;
   d->delete_me = 1;
   
   alflac_destination_set_nothing(d);
   
   return d;

}

void alflac_destination_save_data(ALFLAC_DESTINATION *d){
   /*
   Sets the "save data" flag.
   
   You can use this function if you don't want to automatically
   close a PACKFILE, or to save the ALFLAC_BUFFER from deletion.
   
   This deletes the destination, so you should normally put this
   just before 'alflac_alflac_del'.
   
   For example, to rescue a PACKFILE from being closed:
      ALFLAC *af;
      af = alflac_alflac_new();
      alflac_destination_set_packfile( af->source, pf );
      ...
      alflac_destination_save_data( &(af->source) );
      alflac_alflac_del( af );
      ...
      pack_fclose( pf );

   If you call this for duplicate destinations, the data from the
   duplicate destinations is saved, but the destinations themselves
   are deleted. Ie, you might be left with 2 PACKFILEs; but never
   with a DESTINATION.
   
   */
   
   if (d == NULL)
      return;
   
   /* recursive destinations */
   alflac_destination_save_data( d->duplicate_destination_1 );
   alflac_destination_save_data( d->duplicate_destination_2 );
   
   /* set "delete me" to "no" */
   d->delete_me = 0;
}

void alflac_destination_del(ALFLAC_DESTINATION *d){
   /*
   Closes all open stuff in the ALFLAC_DESTINATION "d", and
   frees "d".
   
   This includes memoy buffers, packfiles, etc. This will also close
   duplicate destinations in the same way.
   */
   if (!d)
      return;
   
   /* delete data within */
   if (d->delete_me != 0)
      alflac_destination_close(d);
   
   free(d->fill_function);
   free(d);
}

void alflac_destination_close(ALFLAC_DESTINATION *d){
   /*
   Closes all open stuff in the ALFLAC_DESTINATION "d"
   
   Sets data type for nothing.
   */
   if (!d)
      return;
   
   /* delete data */
   if (d->data) {
      switch (d->type){
         case ALFLAC_DESTINATION_TYPE_AUDIOSTREAM:
            alflac_audiostream_del((ALFLAC_AUDIOSTREAM *) d->data);
            break;
         case ALFLAC_DESTINATION_TYPE_MEMORY_BUFFER:
            alflac_buffer_del((ALFLAC_BUFFER *) d->data);
            break;
         case ALFLAC_DESTINATION_TYPE_PACKFILE:
            pack_fclose((PACKFILE *) d->data);
            break;
         case ALFLAC_DESTINATION_TYPE_FILE:
            fclose((FILE *) d->data);
            break;
         case ALFLAC_DESTINATION_TYPE_BORROW_DATAFILE:
         {
            /* delete wrapper */
            ALFLAC_BUFFER *buf = (ALFLAC_BUFFER *) d->data;
            alflac_buffer_to_data(&buf, NULL, NULL);
            break;
         }
         case ALFLAC_DESTINATION_TYPE_NOTHING:
         case ALFLAC_DESTINATION_TYPE_CONSOLE:
         case ALFLAC_DESTINATION_TYPE_DUPLICATE:
            /* nothing */
            break;
      }
   }
   
   /* delete duplicate destinations */
   if (d->type == ALFLAC_DESTINATION_TYPE_DUPLICATE) {
      if (d->duplicate_destination_1)
         alflac_destination_del(d->duplicate_destination_1);
      if (d->duplicate_destination_2)
         alflac_destination_del(d->duplicate_destination_2);
   }
   
   
   /* set to NOTHING */
   d->type = ALFLAC_DESTINATION_TYPE_NOTHING;
   
   /* set all to NULL */
   d->data = NULL;
   
   d->duplicate_destination_1 = NULL;
   d->duplicate_destination_2 = NULL;
   
   d->fill_function->fill_function = NULL;
   d->fill_function->output_frame_size = 0;
   d->fill_function->fill_function_table = NULL;

}





int alflac_destination_ready_for_data_read(ALFLAC_DESTINATION *d){
   /*
   returns  POSITIVE if ready for data read
            ZERO     if it's not ready
            NEGATIVE on error
   */
   switch (d->type){
      default:
         break;
   }
   return 1;
}

int alflac_destination_ready_for_data_write(ALFLAC_DESTINATION *d){
   /*
   returns  POSITIVE if ready for data write
            ZERO     if it's not ready
            NEGATIVE on error
   */
   switch (d->type){
      case ALFLAC_DESTINATION_TYPE_AUDIOSTREAM:
         return alflac_audiostream_process((ALFLAC_AUDIOSTREAM *) d->data);
      case ALFLAC_DESTINATION_TYPE_DUPLICATE:
      {
         int temp;
         temp = alflac_destination_ready_for_data_write(d->duplicate_destination_1);
         if (temp <= 0)
            return temp;
         return alflac_destination_ready_for_data_write(d->duplicate_destination_2);
      }
      default:
         break;
   }
   return 1;
}

void alflac_destination_end_of_stream(ALFLAC_DESTINATION *d){
   /*
   This is called at the end of the stream, but before the delete
   functions.
   
   Read and write say they want more data, but there's no more
   data to give from FLAC.
   */
   switch (d->type){
      case ALFLAC_DESTINATION_TYPE_AUDIOSTREAM:
      {
         /*
         Pad end of stream with zeros and say free for the last time.
         */
         ALFLAC_AUDIOSTREAM *aa = d->data;
         if (aa) {
            ALFLAC_BUFFER *b = aa->buffer;
            if (b) {
               int i;
               for (i = b->write_position; i < b->size; i++){
                  b->data[i] = 0;
               }
            }
            alflac_audiostream_free_buffer(aa);
         }
         return;
      }
      case ALFLAC_DESTINATION_TYPE_DUPLICATE:
      {
         alflac_destination_end_of_stream(d->duplicate_destination_1);
         alflac_destination_end_of_stream(d->duplicate_destination_2);
         return;
      }
      default:
         return;
   }
   return;
}




int alflac_destination_set_fill_function_table(ALFLAC_DESTINATION *dest, ALFLAC_FILL_FUNCTION_PICKER *pick){
   if (!dest)
      return 1;
   
   dest->fill_function->fill_function_table = pick;
   return 0;
}

af_uint alflac_destination_frame_size(ALFLAC_DESTINATION *dest) {
   /*
   returns size of frame size from a destination
   */
   if (!dest)
      return 0;
   
   return dest->fill_function->output_frame_size;
}

void alflac_destination_pick_function_from_table(ALFLAC_DESTINATION *dest, ALFLAC_INFO *info){
   /*
   Picks a fill_function for "dest" from "dest->fill_function_table"
   Is recursive through duplicate_dest.   
   
   This is called when INFO structure is made.
   */
   int i=0;
   ALFLAC_FILL_FUNCTION_PICKER *ff;
   
   if (!dest || !info)
      return;
   
   /* be recursive if needed */
   if (dest->duplicate_destination_1)
      alflac_destination_pick_function_from_table(dest->duplicate_destination_1, info);
   if (dest->duplicate_destination_2)
      alflac_destination_pick_function_from_table(dest->duplicate_destination_2, info);
   
   /* already got a fill_function */
   if (dest->fill_function->fill_function != NULL)
      return;
   
   /* get fill_function_table */
   ff = dest->fill_function->fill_function_table;
   if (!ff)
      return;
   
   /* go through list */
   for (;;) {
      /* end of list */
      if (ff[i].channels == 0
       && ff[i].bits == 0
      ) break;
      
      /* is ok? */
      if (ff[i].channels == info->channels
       || ff[i].channels == 0
      ) {
         if (ff[i].bits == info->bits) {
            dest->fill_function->fill_function = ff[i].fill_function;
            dest->fill_function->output_frame_size = ff[i].output_frame_size;
            break;
         }
      }
      i++;
   }
}







int alflac_destination_set_nothing(ALFLAC_DESTINATION *d){
   /*
   clears data from an ALFLAC_DESTINATION, and sets it to
   send decoded data to hell.
   
   Returns zero on success
           nonzero on error (same for those below).
   */
   if (!d)
      return 1;
   
   alflac_destination_close(d);
   
   d->type = ALFLAC_DESTINATION_TYPE_NOTHING;
  
   return 0;
}

int alflac_destination_set_audiostream(ALFLAC_DESTINATION *d, af_uint buffer_size){
   /*
   Sets the ALFLAC_DESTINATION to stream to Allegro audio in the background.
   */
   if (alflac_destination_set_nothing(d))
      return 1;
   
   if (d->is_source)
      return 2;
      
   d->type = ALFLAC_DESTINATION_TYPE_AUDIOSTREAM;
   d->fill_function->fill_function_table = fill_function_table_default;
   
   d->data = alflac_audiostream_new(buffer_size);
      
   return 0;
}


int alflac_destination_set_memory_buffer(ALFLAC_DESTINATION *d, ALFLAC_BUFFER *buf){
   /*
   Sets the ALFLAC_DESTINATION to stream into "buf". 
   */
   if (!buf)
      return 10;

   if (alflac_destination_set_nothing(d))
      return 1;
   
   d->type = ALFLAC_DESTINATION_TYPE_MEMORY_BUFFER;
   d->fill_function->fill_function_table = fill_function_table_default;   
   d->data = buf;
      
   return 0;
}

int alflac_destination_set_packfile(ALFLAC_DESTINATION *d, PACKFILE *pack){
   /*
   Sets the ALFLAC_DESTINATION to read or write "pack"
   */
   if (!pack)
      return 10;
   
   if (alflac_destination_set_nothing(d))
      return 1;
      
   d->type = ALFLAC_DESTINATION_TYPE_PACKFILE;
   d->fill_function->fill_function_table = fill_function_table_default;   
   d->data = pack;
      
   return 0;
}

int alflac_destination_set_console(ALFLAC_DESTINATION *d){
   /*
   Sets the ALFLAC_DESTINATION to dump to console
   */
   if (alflac_destination_set_nothing(d))
      return 1;
        
   if (d->is_source)
      return 2;
   
   d->type = ALFLAC_DESTINATION_TYPE_CONSOLE;
   d->fill_function->fill_function_table = fill_function_table_default;   
      
   return 0;
}


int alflac_destination_set_duplicate(ALFLAC_DESTINATION *d, ALFLAC_DESTINATION **dup1, ALFLAC_DESTINATION **dup2){
   /*
   Sets the ALFLAC_DESTINATION to send to swo locations. These locations are
   created onto "dup1" and "dup2".
   */
   if (alflac_destination_set_nothing(d))
      return 1;
   
   *dup1 = alflac_destination_new(d->is_source);
   *dup2 = alflac_destination_new(d->is_source);
   
   d->type = ALFLAC_DESTINATION_TYPE_DUPLICATE;
   d->duplicate_destination_1 = *dup1;
   d->duplicate_destination_2 = *dup2;
      
   return 0;
}


int alflac_destination_set_file(ALFLAC_DESTINATION *d, FILE *fp){
   /*
   Sets the ALFLAC_DESTINATION to a FILE. Provide an open file as "fp"
   */
   if (!fp)
      return 10;
   
   if (alflac_destination_set_nothing(d))
      return 1;
        
   d->type = ALFLAC_DESTINATION_TYPE_FILE;
   d->data = fp;
   d->fill_function->fill_function_table = fill_function_table_default;   
      
   return 0;
}

int alflac_destination_set_borrow_datafile(ALFLAC_DESTINATION *d, DATAFILE *df, int df_index){
   /*
   Sets the ALFLAC_DESTINATION to data in an allegro datafile.
   
   "df" is the datafile, and "df_index" is the index of the data.
   
   NOTE: "df" will NOT be closed on exit.
   */
   if (!df)
      return 10;
      
   if (!df[df_index].dat || df[df_index].size <= 4)
      return 11;
      
   if (strncmp(df[df_index].dat, "fLaC", 4) != 0) {
      alflac_error_god("Data in the datafile does not begin with fLaC");
      return 12;
   }
   
   if (alflac_destination_set_nothing(d))
      return 1;
   
   d->type = ALFLAC_DESTINATION_TYPE_BORROW_DATAFILE;
   d->data = alflac_buffer_from_data(df[df_index].dat, df[df_index].size);
   d->fill_function->fill_function_table = fill_function_table_default;
   
   return 0;
}

