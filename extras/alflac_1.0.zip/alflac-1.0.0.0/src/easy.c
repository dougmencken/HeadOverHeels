/* ALFLAC - libFLAC for Allegro
 * Copyright (C) 2006, David Batley, CompuNach
 *
 * This code is avaliable for distribution under the Xiph License (below).
 *
 * You may also distribute the code below under the GNU General Public
 * License (GPL).
 * 
 * Xiph (BSD-style) License
 * ========================
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * - Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 *
 * - Neither the name of the Xiph.org Foundation nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE FOUNDATION OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include <alflac/_internal.h>

/*proto */

void *alflac_allegro_datafile_load(PACKFILE *f, long size) ;
void alflac_allegro_datafile_unload(void *data) ;
SAMPLE *just_like_create_sample(int bits, int stereo, int freq, int len, void *data);


/*func*/


ALFLAC *alflac_do_file_to_audiostream(char *name, af_uint buffer_size){
   /*
   Creates an ALFLAC structure to play the file "name" as an
   allegro stream with allegro buffer size "buffer_size".
   
   "buffer_size" should be about 4 KB = 4 * (1 << 10); or 8 KB
   8 * (1 << 10).
   
   EXAMPLE OF USE
   ==============
         
      ALFLAC *af = NULL;
      af = alflac_do_file_to_audiostream( "my.flac", 4 * (1<<10) );
      while ( !key[KEY_ESC] ) {
         if ( alflac_poll_all(af) <= 0 ) 
            break;
      }
      alflac_alflac_end(af); af = NULL;
      
   */
   ALFLAC *af;
   PACKFILE *pf;
   
   pf = pack_fopen(name, F_READ);
   if (!pf)
      return NULL;
   
   af = alflac_alflac_new();
   if (!af)
      return NULL;
   
   alflac_destination_set_packfile(af->source, pf);
   alflac_destination_set_audiostream(af->destination, buffer_size);

   return af;
}



ALFLAC *alflac_do_datafile_to_audiostream(DATAFILE *df, int df_index, af_uint buffer_size){
   /*
   Creates an ALFLAC structure to play data from an Allegro datafile as an
   allegro stream with allegro buffer size "buffer_size".
   
   "df" wil NOT be closed when audiostream exits.
   
   "buffer_size" should be about 4 KB = 4 * (1 << 10); or 8 KB
   8 * (1 << 10).
   
   EXAMPLE OF USE
   ==============
      ALFLAC *af = NULL;
      DATAFILE *df = load_datafile("df.dat");
      
      af = alflac_do_file_to_audiostream( df, DF_FLAC_FILE, 4 * (1<<10) );
      while ( !key[KEY_ESC] ) {
         if ( alflac_poll_all(af) <= 0 ) 
            break;
      }
      alflac_alflac_end(af); af = NULL;
      
   */
   ALFLAC *af;
   
   if (!df)
      return NULL;

   af = alflac_alflac_new();
   if (!af)
      return NULL;
   
   alflac_destination_set_borrow_datafile(af->source, df, df_index);
   alflac_destination_set_audiostream(af->destination, buffer_size);

   return af;
}



ALFLAC *alflac_do_file_to_audiostream_and_console(char *name, af_uint buffer_size){
   /*
   Creates an ALFLAC structure, as above, except it will duplicate
   the output. The data will be sent to the console (sdtout) and also
   streamed with Allegro.
   */
   ALFLAC *af;
   PACKFILE *pf;
   
   pf = pack_fopen(name, F_READ);
   if (!pf)
      return NULL;
   
   af = alflac_alflac_new();
   if (!af)
      return NULL;
   
   alflac_destination_set_packfile(af->source, pf);
   
   {
      ALFLAC_DESTINATION *d1, *d2;
      alflac_destination_set_duplicate(af->destination, &d1, &d2);
      alflac_destination_set_audiostream(d1, buffer_size);
      alflac_destination_set_console(d2);
   }
   

   return af;
}


void alflac_for_allegro(){
   /*
   Plugs alflac into allegro
   
   Call this function after loading allegro to use FLAC files easily in allegro.
   */
   
   register_sample_file_type("flac", alflac_do_file_to_sample, NULL);
   register_datafile_object(AL_ID('F','L','A','W'), alflac_allegro_datafile_load, alflac_allegro_datafile_unload);
}


SAMPLE *alflac_do_file_to_sample(const char *filename){
   /*
   Creates an allegro SAMPLE from a .flac file, "filename".
   */
   PACKFILE *pf = NULL;
   SAMPLE *s = NULL;
   
   pf = pack_fopen(filename, F_READ);
   if (!pf)
      return NULL;
      
   s = alflac_do_packfile_to_sample(pf);
   
   pack_fclose(pf);
   return s;
}

SAMPLE *alflac_do_packfile_to_sample(PACKFILE *pf){
   /*
   Creates a SAMPLE from a PACKFILE
   
   This function keeps "pf" open.
   */
   ALFLAC *af = NULL;
   ALFLAC_BUFFER *buf = NULL;
   SAMPLE *spl = NULL;
   
   buf = alflac_buffer_new(0);
   if (!buf)
      goto error;
   
   af = alflac_alflac_new();
   if (!af)
      goto error;
   
   /* sorce is packfile, do not automatically close */
   alflac_destination_set_packfile(af->source, pf);
   alflac_destination_save_data( af->source );
   
   /* destination is buffer, DO automatically close */
   alflac_destination_set_memory_buffer(af->destination, buf);

   /* poll to end of file (or error). */
   if (
      alflac_poll_all(af)
   < 0) {
      alflac_error_god("SAMPLE has bad data or errors (see above).");
   }
   
   if (!af || !af->info)
      goto error;
   
   {
      af_uint buf_size;          /* size of buf_data, in bytes */
      af_byte *buf_data;         /* sample data */
      af_uint frames_length;     /* length of sample in frames */
      af_uint bytes_per_frame;   /* number of bytes in each frame */
      
      bytes_per_frame = alflac_destination_frame_size(af->destination);
      if (!bytes_per_frame)
         goto error;
      
      /* divorce the data from the buffer (set buffer to no data).
      The buffer will deleted when ALFLAC is deleted */
      alflac_buffer_divorce_data(buf, &buf_data, &buf_size);
      if (buf_data == NULL || buf_size <= 0)
         goto error;
      
      frames_length = buf_size / bytes_per_frame;

      spl = just_like_create_sample(
         af->info->bits,
         (af->info->channels >= 2) ? TRUE : FALSE,
         af->info->frequency,
         frames_length,
         buf_data
      );
      
      if (!spl)
         goto error;
   }
   
   /* clean up */
   alflac_alflac_del(af);

   return spl;

error:
   
   /* ALFLAC structure and everything in it (including destinations) */
   if (af) {
      alflac_alflac_del(af);
   } else {
      /* (do not close packfile) */
   }
   
   /* buffer always survives (even if it is a destination) */
   if (buf)
      alflac_buffer_del(buf);
   
   /* spl not touched by alflac */
   if (spl)
      free(spl);
   
   /* die */
   return NULL;
}


/*
Support for FLAW datafile objects.

FLAW objects are FLAC files stored in the datafile. When you load the
datafile, the FLAC data is converted into a SAMPLE structure (ie, raw
WAVE data).

The Wave data will take up about twice the size of the FLAC data.
Decoding the FLAC data also takes a moment, making load_datafile slow
for these items.

FLAW objects should be exactly the same as the file, (ie, starting
with the "FLAC" magic id onwards).

On failure, the sample will be NULL.
*/

void *alflac_allegro_datafile_load(PACKFILE *f, long size) {
   /*
   returns (SAMPLE *) sample.
   
   packfile "f" will EOF past end of file, so safe to ignore
   "size".
   
   'packfile_to_sample' keeps the packfile open, so that's good.
   */
   return alflac_do_packfile_to_sample(f);
}

void alflac_allegro_datafile_unload(void *data) {
   /*
   "FLAW" entries are really "SAMP" entries when opened.
   */
   if (data)
      destroy_sample((SAMPLE *) data);
}


SAMPLE *just_like_create_sample(int bits, int stereo, int freq, int len, void *data) {
   /*
   This function is just like 'create_sample' in Allegro ("allegro/src/sound.c"), but
   where that function mallocs a buffer, we just use "data"
   */
   
   SAMPLE *spl;
   
   /* ASSERTs -> if */
   if (freq <= 0 || len <= 0)
      return NULL;

   spl = malloc(sizeof(SAMPLE)); 
   if (!spl)
      return NULL;

   spl->bits = bits;
   spl->stereo = stereo;
   spl->freq = freq;
   spl->priority = 128;
   spl->len = len;
   spl->loop_start = 0;
   spl->loop_end = len;
   spl->param = 0;
   
   /* malloc -> assignment */
   spl->data = data;

   lock_sample(spl);
   return spl;
}
