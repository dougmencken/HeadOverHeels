/* ALFLAC - libFLAC for Allegro
 * Copyright (C) 2006, David Batley, CompuNach
 *
 * This code is avaliable for distribution under the Xiph License (below).
 *
 * You may also distribute the code below under the GNU General Public
 * License (GPL).
 * 
 * Xiph (BSD-style) License
 * ========================
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * - Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 *
 * - Neither the name of the Xiph.org Foundation nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE FOUNDATION OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include <alflac/_internal.h>

/*
   fill_function_table_default:
      The functions listed are for standard WAVE output, in the format
      Allegro uses (ie, little endian).
*/
ALFLAC_FILL_FUNCTION_PICKER fill_function_table_default[5] = {
/* |-- input --||---- output ----| */
/*  bits  chan   out    function   */
   {  8,    2,    2,    copy_frame_indep_bit8   },
   { 16,    2,    4,    copy_frame_indep_bit16i },
   {  8,    1,    1,    copy_frame_chan0_bit8   },
   { 16,    1,    2,    copy_frame_chan0_bit16i },
   {  0,    0,    0,    NULL                    }
};


/*
   fill_function_table_default_to_mono:
      The functions listed are for standard WAVE output, in the format
      Allegro uses (ie little endian).
      If the FLAC file is in stereo, it is converted to mono for the
      output.
*/
ALFLAC_FILL_FUNCTION_PICKER fill_function_table_default_to_mono[5] = {
/* |-- input --||---- output ----| */
/*  bits  chan   out    function   */
   {  8,    2,    1,    copy_frame_indep_to_mono_bit8   },
   { 16,    2,    2,    copy_frame_indep_to_mono_bit16i },
   {  8,    1,    1,    copy_frame_chan0_bit8   },
   { 16,    1,    2,    copy_frame_chan0_bit16i },
   {  0,    0,    0,    NULL                    }
};


/*
   fill_function_table_big_endian:
      The functions listed are for big endian output.
*/
ALFLAC_FILL_FUNCTION_PICKER fill_function_table_big_endian[5] = {
/* |-- input --||---- output ----| */
/*  bits  chan   out    function   */
   {  8,    2,    2,    copy_frame_indep_bit8   },
   { 16,    2,    4,    copy_frame_indep_bit16m },
   {  8,    1,    1,    copy_frame_chan0_bit8   },
   { 16,    1,    2,    copy_frame_chan0_bit16m },
   {  0,    0,    0,    NULL                    }
};


/* FUNCTIONS

   The "i" or "m" at the end of bit16 or bit32 indicates byte order.
   i = Intel      = Little Endian   = Most significant byte on Right
   m = Motorolla  = Big endian      = Most Significant Bit on Left
   
   "albuf"
      is a buffer to fill
   "b1"
      is one frame of decoded data (a signed 32-bit) from "channel 0"
   "b2"
      is one frame of decoded data from "channel 1". If there's only
      one channel, "b2" will also be the data from "channel 0"

*/

/* _________________________________________________________________
   
   copy_frame_chan0_*
      Use data from chan0 only.
      Stereo stream     -> Left Channel as mono output
      Mono Stream       -> Mono Channel
*/

void copy_frame_chan0_bit8  (af_byte *albuf, FLAC__int32 b1, FLAC__int32 b2){
   /* fixupp signage */
   b1 += 0x00000080;
   
   *(albuf+0) = b1 & 0x000000ff;
}

void copy_frame_chan0_bit16i (af_byte *albuf, FLAC__int32 b1, FLAC__int32 b2){
   b1 += 0x00008000;
   
   *(albuf+0) = b1 & 0x000000ff;
   *(albuf+1) = (b1 & 0x0000ff00) >> 8;
}

void copy_frame_chan0_bit16m (af_byte *albuf, FLAC__int32 b1, FLAC__int32 b2){
   b1 += 0x00008000;
   
   *(albuf+1) = b1 & 0x000000ff;
   *(albuf+0) = (b1 & 0x0000ff00) >> 8;
}


/* _________________________________________________________________
   
   copy_frame_chan1_*
      Use data from chan1 only.
      Stereo stream     -> Right Channel as mono output
      Mono Stream       -> Mono Channel
*/


void copy_frame_chan1_bit8  (af_byte *albuf, FLAC__int32 b1, FLAC__int32 b2){
   b2 += 0x00000080;
   
   *(albuf+0) = b2 & 0x000000ff;
}

void copy_frame_chan1_bit16i (af_byte *albuf, FLAC__int32 b1, FLAC__int32 b2){
   b2 += 0x00008000;
   
   *(albuf+0) = b2 & 0x000000ff;
   *(albuf+1) = (b2 & 0x0000ff00) >> 8;
}

void copy_frame_chan1_bit16m (af_byte *albuf, FLAC__int32 b1, FLAC__int32 b2){
   b2 += 0x00008000;
   
   *(albuf+1) = b2 & 0x000000ff;
   *(albuf+0) = (b2 & 0x0000ff00) >> 8;
}





/* _________________________________________________________________
   
   copy_frame_indep_*
      Create a stereo stream of independant channels
      Stereo stream     -> Stereo output
      Mono Stream       -> Stereo stream with the left stream the same
                           as the right stream
*/


void copy_frame_indep_bit8  (af_byte *albuf, FLAC__int32 b1, FLAC__int32 b2){
   b1 += 0x00000080;
   b2 += 0x00000080;
   
   *(albuf+0) = b1 & 0x000000ff;
   *(albuf+1) = b2 & 0x000000ff;
}

void copy_frame_indep_bit16i (af_byte *albuf, FLAC__int32 b1, FLAC__int32 b2){
   b1 += 0x00008000;
   b2 += 0x00008000;
   
   *(albuf+0) = b1 & 0x000000ff;
   *(albuf+1) = (b1 & 0x0000ff00) >> 8;
   
   *(albuf+2) = b2 & 0x000000ff;
   *(albuf+3) = (b2 & 0x0000ff00) >> 8;
}

void copy_frame_indep_bit16m (af_byte *albuf, FLAC__int32 b1, FLAC__int32 b2){
   b1 += 0x00008000;
   b2 += 0x00008000;
   
   *(albuf+1) = b1 & 0x000000ff;
   *(albuf+0) = (b1 & 0x0000ff00) >> 8;
   
   *(albuf+3) = b2 & 0x000000ff;
   *(albuf+2) = (b2 & 0x0000ff00) >> 8;
}




/* _________________________________________________________________
   
   copy_frame_indep_to_mono_*
      Create a stereo stream of independant channels
      Stereo stream     -> Stereo output
      Mono Stream       -> Stereo stream with the left stream the same
                           as the right stream
*/

void copy_frame_indep_to_mono_bit8  (af_byte *albuf, FLAC__int32 b1, FLAC__int32 b2){
   b1 += 0x00000080;
   b2 += 0x00000080;
   
   b1 &= 0x000000ff;
   b2 &= 0x000000ff;
   
   /* output is average...*/
   /* ... add ... */
   b1 += b2;
   /* ... and divide by 2 (using right-bitshift for extra speed,
   not that it really matters) */
   *(albuf+0) = (b1 >> 1);
}


void copy_frame_indep_to_mono_bit16i (af_byte *albuf, FLAC__int32 b1, FLAC__int32 b2){
   b1 += 0x00008000;
   b2 += 0x00008000;
   
   /* sum and divide by 2 */
   b1 += b2;
   b1 >>= 1;
   
   /* set */
   *(albuf+0) = b1 & 0x000000ff;
   *(albuf+1) = (b1 & 0x0000ff00) >> 8;
}


void copy_frame_indep_to_mono_bit16m (af_byte *albuf, FLAC__int32 b1, FLAC__int32 b2){
   b1 += 0x00008000;
   b2 += 0x00008000;
   
   /* sum and divide by 2 */
   b1 += b2;
   b1 >>= 1;
   
   /* set */
   *(albuf+1) = b1 & 0x000000ff;
   *(albuf+0) = (b1 & 0x0000ff00) >> 8;
}


