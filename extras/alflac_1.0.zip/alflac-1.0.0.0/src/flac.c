/* ALFLAC - libFLAC for Allegro
 * Copyright (C) 2006, David Batley, CompuNach
 *
 * This code is avaliable for distribution under the Xiph License (below).
 *
 * You may also distribute the code below under the GNU General Public
 * License (GPL).
 * 
 * Xiph (BSD-style) License
 * ========================
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * - Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 *
 * - Neither the name of the Xiph.org Foundation nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE FOUNDATION OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include <FLAC/all.h>
#include <alflac/_internal.h>



ALFLAC_FLAC *alflac_flac_new(ALFLAC *alflac){
   /* alflac_flac_new
      This makes a new decoder, and sets it up.
      "alflac" is for the client data on the callbacks.
   */
   
   ALFLAC_FLAC *z = malloc(sizeof(ALFLAC_FLAC));
   if (!z)
      return NULL;
   
   z->reached_end_of_stream = 0;
   z->decoder = FLAC__stream_decoder_new();
   if (!z->decoder) {
      free(z);
      return NULL;
   }
   
   if (alflac_flac_setup_decoder(z, alflac) != 0) {
      alflac_flac_del(z);
      return NULL;
   }
   
   return z;
}

void alflac_flac_del(ALFLAC_FLAC *z){
   /* alflac_flac_del
      This destroys ALFLAC_FLAC and the decoder within it.
   */
   
   if (!z)
      return;
   
   if (z->decoder) {
      FLAC__stream_decoder_finish(z->decoder);
      FLAC__stream_decoder_delete(z->decoder);
   }
   
   free(z);
}


int alflac_flac_setup_decoder(ALFLAC_FLAC *z, ALFLAC *alflac) {
   /* alflac_flac_setup_decoder
      Sets up the decoder for normal use.
      "alflac" is for the client data given to all the callbacks.
      return NONZERO on error
   */

   FLAC__StreamDecoder *decoder;
   if (!z)
      return 11;
   
   decoder = z->decoder;
   if (!decoder)
      return 12;

   /* decoder settings, callbacks */
   FLAC__stream_decoder_set_read_callback(decoder, alflac_callback_read);
   FLAC__stream_decoder_set_write_callback(decoder, alflac_callback_write);
   FLAC__stream_decoder_set_metadata_callback(decoder, alflac_callback_metadata);
   FLAC__stream_decoder_set_error_callback(decoder, alflac_callback_error);
   
   /* pass "alflac" to callbacks */
   FLAC__stream_decoder_set_client_data (decoder, alflac);
   
   /* respond to everything (for now, EDIT THIS later) */
   FLAC__stream_decoder_set_metadata_respond_all (z->decoder);
   
   /* Initiate */
   if (
      FLAC__stream_decoder_init(z->decoder)
   != FLAC__STREAM_DECODER_SEARCH_FOR_METADATA) {
      return 30;
   }
   
   /* OK */
   return 0;
}

int alflac_flac_process(ALFLAC_FLAC *z, int to_end_of_stream) {
   /* alflac_flac_process
      Processes the audio, which in turn calls the callback funstions.
      
      Set "to_end_of_stream" to process it all in one go, else only
      one frame will be decoded.
      
      Returns NEGATIVE  on error
              POSITIVE  on end of stream
              ZERO      on success
   */
   
   if (to_end_of_stream)
      FLAC__stream_decoder_process_until_end_of_stream(z->decoder);
   else
      FLAC__stream_decoder_process_single(z->decoder);
   
   switch (FLAC__stream_decoder_get_state(z->decoder)) {
      case FLAC__STREAM_DECODER_END_OF_STREAM:
         return 1;
      case FLAC__STREAM_DECODER_ABORTED:
         return -1;
      case FLAC__STREAM_DECODER_UNPARSEABLE_STREAM:
         return -2;
      case FLAC__STREAM_DECODER_MEMORY_ALLOCATION_ERROR:
         return -99;
      case FLAC__STREAM_DECODER_INVALID_CALLBACK:
         return -4;
      case FLAC__STREAM_DECODER_UNINITIALIZED:
         return -5;
      default:
         /* OK (I hope) */
         break;
   }
   return 0;
}

