/*
   This header file is placed in the Public Domain.
   ALFLAC and libFLAC are licensed under the Xiph License.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h> /* memcpy */

#include <allegro.h>

#include "_options.h"
#include "_dll_magic.h"
#include "_types.h"

#include "alflac.h"
#include "audiostream.h"
#include "buffer.h"
#include "callback.h"
#include "destination.h"
#include "easy.h"
#include "error.h"
#include "fill_functions.h"
#include "flac.h"
#include "info.h"
#include "save.h"

