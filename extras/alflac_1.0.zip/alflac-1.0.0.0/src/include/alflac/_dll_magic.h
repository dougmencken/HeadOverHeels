/*
   This header file is placed in the Public Domain.
   ALFLAC and libFLAC are licensed under the Xiph License.
*/

/*
is this a system for DLLs?
Define ALFLAC_NO_DLL for static on windows.
*/
#ifdef WIN32
#  ifndef ALFLAC_NO_DLL
#     define ALFLAC_MAKE_DLL
#  endif
#endif


#ifdef ALFLAC_MAKE_DLL
/* dll */
#  ifdef ALFLAC_INTERNAL
#     define ALFLAC_API __declspec( dllexport )
#     define ALFLAC_ONLY
#  else
#     define ALFLAC_API __declspec( dllimport )
#     define ALFLAC_ONLY
#  endif
#else
/* static */
#  ifdef ALFLAC_INTERNAL
#     define ALFLAC_API extern
#     define ALFLAC_ONLY
#  else
#     define ALFLAC_API extern
#     define ALFLAC_ONLY
#  endif
#endif

