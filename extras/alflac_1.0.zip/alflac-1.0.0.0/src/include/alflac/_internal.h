/*
   This header file is placed in the Public Domain.
   ALFLAC and libFLAC are licensed under the Xiph License.
*/

#define ALFLAC_INTERNAL
#include "_all.h"

