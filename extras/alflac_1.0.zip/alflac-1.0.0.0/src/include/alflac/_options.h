/*
   This header file is placed in the Public Domain.
   ALFLAC and libFLAC are licensed under the Xiph License.
*/

#define ALFLAC_VER_MAJ        1
#define ALFLAC_VER_MIN        0
#define ALFLAC_VER_SUB        0
#define ALFLAC_VER_BUILD      0
#define ALFLAC_VER_STRING     "1.0.0.0"

#define ALFLAC_NAME_SHORT     "ALFLAC"
#define ALFLAC_NAME_VER       "CompuNach ALFLAC 1.0.0.0"
#define ALFLAC_NAME_LONG      "CompuNach ALFLAC: FLAC Support for Allegro"

#define ALFLAC_INFO_COPYRIGHT "ALFLAC Copyright (c) 2006 CompuNach; libFLAC Copyright (c) Josh Coalson. Copyleft (>) under Xiph License"
#define ALFLAC_INFO_CONTACT   "Visit compunach.co.nr for details"

#define ALFLAC_INFO_AUTHORS   "CompuNach, libFLAC by Josh Coalson"

