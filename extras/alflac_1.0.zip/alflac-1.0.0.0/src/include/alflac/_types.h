/*
   This header file is placed in the Public Domain.
   ALFLAC and libFLAC are licensed under the Xiph License.
*/

/* types */
typedef unsigned char   af_byte;
typedef unsigned int    af_uint;
typedef signed char     af_bool;

/* FLAC__int32 etc */
#ifndef FLAC__ORDINALS_H
#  include "_libflac_ordinals.h"
#endif

/* function to copy data from FLAC buffer to alleg buffer. */
typedef void ALFLAC_FILL_FUNCTION(
   af_byte      * buffer,
   FLAC__int32    data0,
   FLAC__int32    data1
);

/* from .h files */
typedef struct stALFLAC_BUFFER
                   ALFLAC_BUFFER;
typedef struct stALFLAC_DESTINATION
                   ALFLAC_DESTINATION;
typedef struct stALFLAC_FLAC
                   ALFLAC_FLAC;
typedef struct stALFLAC_INFO
                   ALFLAC_INFO;
typedef struct stALFLAC_AUDIOSTREAM
                   ALFLAC_AUDIOSTREAM;
typedef struct stALFLAC
                   ALFLAC;
typedef struct stALFLAC_FILL_FUNCTION_PICKER
                   ALFLAC_FILL_FUNCTION_PICKER;
typedef struct stALFLAC_DESTINATION_FILL_FUNCTION
                   ALFLAC_DESTINATION_FILL_FUNCTION;




