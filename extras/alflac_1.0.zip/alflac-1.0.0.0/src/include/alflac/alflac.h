/*
   This header file is placed in the Public Domain.
   ALFLAC and libFLAC are licensed under the Xiph License.
*/

struct stALFLAC {
   
   ALFLAC_FLAC *
      flac;
      /* flac
         The FLAC decoder and any other stuff for internal FLAC use.
      */
   
   ALFLAC_INFO *
      info;
      /* info
         Channels, bitrate, etc
         This is NULL pointer until the frequency, bitrate, etc are
         found normally made during the first call to 'alflac_poll'.
      */
   
   ALFLAC_DESTINATION *
      source;
      /* source
         Information about where to read data from.
         You should pass this to 'alflac_destination_set_*' to provide
         a source.
      */
      
   ALFLAC_DESTINATION *
      destination;
      /* destination
         Information about where to place decoded output, and what
         fill functions to use (ie, what format to use for the output).
         You should pass this to 'alflac_destination_set_*' to provide
         a destination.
      */
     
};


/*
These are the "big 3" to use:
Also look at destination.h
*/
ALFLAC_API ALFLAC *alflac_alflac_new();
ALFLAC_API void alflac_alflac_del(ALFLAC *af);
ALFLAC_API int alflac_poll(ALFLAC *af);
ALFLAC_API int alflac_poll_all(ALFLAC *af);

/* information */
ALFLAC_API const char *alflac_id;
ALFLAC_API const int alflac_version[4];
ALFLAC_API const char *alflac_id_copyright;
ALFLAC_API const char *alflac_id_contact;
ALFLAC_API const char *alflac_id_authors;

