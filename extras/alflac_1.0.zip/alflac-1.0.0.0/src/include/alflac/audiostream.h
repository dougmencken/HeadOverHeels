/*
   This header file is placed in the Public Domain.
   ALFLAC and libFLAC are licensed under the Xiph License.
*/

struct stALFLAC_AUDIOSTREAM {
   
   AUDIOSTREAM *
      audiostream;
      /*
      Allegro Audiostream
      */
      
   af_uint
      buffer_size;
      /*
      Buffer size, in bytes
      */
   
   ALFLAC_BUFFER *
      buffer;
      /*
      the data buffer to fill, or NULL
      */

   ALFLAC_BUFFER *
      overflow;
      /*
      overflow buffer, if data cannot fit into buffer
      */
   
};

#ifdef ALFLAC_INTERNAL

ALFLAC_ONLY ALFLAC_AUDIOSTREAM *alflac_audiostream_new(af_uint buffer_size);
ALFLAC_ONLY void alflac_audiostream_del(ALFLAC_AUDIOSTREAM *a);
ALFLAC_ONLY int alflac_audiostream_start_play(ALFLAC_AUDIOSTREAM *a, ALFLAC_INFO *info, af_uint frame_size);
ALFLAC_ONLY int alflac_audiostream_process(ALFLAC_AUDIOSTREAM *a);
ALFLAC_ONLY void alflac_audiostream_make_buffer(ALFLAC_AUDIOSTREAM *a);
ALFLAC_ONLY void alflac_audiostream_free_buffer(ALFLAC_AUDIOSTREAM *a);

#endif

