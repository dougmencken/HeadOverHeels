/*
   This header file is placed in the Public Domain.
   ALFLAC and libFLAC are licensed under the Xiph License.
*/

struct stALFLAC_BUFFER {
   /* ALFLAC_BUFFER
      A buffer
   */
   
   af_byte *
      data;
      
   af_uint
      size;

   af_uint
      read_position;
      
   af_uint
      write_position;
      
};


ALFLAC_API ALFLAC_BUFFER *alflac_buffer_new(af_uint size);
ALFLAC_API void alflac_buffer_del(ALFLAC_BUFFER *buf);

ALFLAC_API int alflac_buffer_fill(ALFLAC_BUFFER *buf, af_byte *data, af_uint size);
ALFLAC_API ALFLAC_BUFFER *alflac_buffer_fill_overflow(ALFLAC_BUFFER *buf, af_byte *data, af_uint size);
ALFLAC_API int alflac_buffer_fill_resize(ALFLAC_BUFFER *buf, af_byte *data, af_uint size);
ALFLAC_API int alflac_buffer_resize(ALFLAC_BUFFER *buf, af_uint size);
ALFLAC_API int alflac_buffer_fill_from(ALFLAC_BUFFER *dest, ALFLAC_BUFFER *source, af_uint max) ;
ALFLAC_API int alflac_buffer_read(ALFLAC_BUFFER *buf, af_byte *data, af_uint *size);

ALFLAC_API void alflac_buffer_to_data(ALFLAC_BUFFER **buf, af_byte **data, af_uint *size);
ALFLAC_API ALFLAC_BUFFER *alflac_buffer_from_data(af_byte *data, af_uint size);
ALFLAC_API void alflac_buffer_divorce_data(ALFLAC_BUFFER *buf, af_byte **data, af_uint *size);

ALFLAC_API af_bool alflac_buffer_is_read_to_end(ALFLAC_BUFFER *buf);
ALFLAC_API af_bool alflac_buffer_is_full(ALFLAC_BUFFER *buf);


