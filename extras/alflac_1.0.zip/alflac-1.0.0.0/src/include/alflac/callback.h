/*
   This header file is placed in the Public Domain.
   ALFLAC and libFLAC are licensed under the Xiph License.
*/
/*
   These are the direct callbacks from FLAC, which cope with reading
   and writing data.
   These are for internal use, for .c files using full flac headers.
*/
#ifdef ALFLAC_INTERNAL
#ifdef FLAC__STREAM_DECODER_H


ALFLAC_ONLY
void alflac_callback_metadata(
   const FLAC__StreamDecoder *decoder,
   const FLAC__StreamMetadata *metadata,
   void *client_data
);

ALFLAC_ONLY
void alflac_callback_error(
   const FLAC__StreamDecoder *decoder,
   FLAC__StreamDecoderErrorStatus status,
   void *client_data
);

ALFLAC_ONLY
FLAC__StreamDecoderReadStatus alflac_callback_read(
   const FLAC__StreamDecoder *decoder,
   FLAC__byte buffer[],
   unsigned *bytes,
   void *client_data
);

ALFLAC_ONLY
FLAC__StreamDecoderWriteStatus alflac_callback_write(
   const FLAC__StreamDecoder *decoder,
   const FLAC__Frame *frame,
   const FLAC__int32 * const buffer[],
   void *client_data
);


#endif
#endif

