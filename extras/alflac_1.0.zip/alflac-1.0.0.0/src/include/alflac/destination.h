/*
   This header file is placed in the Public Domain.
   ALFLAC and libFLAC are licensed under the Xiph License.
*/

typedef enum {
   ALFLAC_DESTINATION_TYPE_NOTHING,
   ALFLAC_DESTINATION_TYPE_AUDIOSTREAM,
   ALFLAC_DESTINATION_TYPE_MEMORY_BUFFER,
   ALFLAC_DESTINATION_TYPE_PACKFILE,
   ALFLAC_DESTINATION_TYPE_DUPLICATE,
   ALFLAC_DESTINATION_TYPE_CONSOLE,
   ALFLAC_DESTINATION_TYPE_FILE,
   ALFLAC_DESTINATION_TYPE_BORROW_DATAFILE
} ALFLAC_DESTINATION_TYPE;

struct stALFLAC_DESTINATION {
   /* ALFLAC_DESTINATION
      Says where to write data to (or read data from)
      
      You should generally only change this structure through the
      alflac_destination_* functions.
   */
   
   ALFLAC_DESTINATION_TYPE
      type;
      /*
      Where to send the data
      */
      
   af_bool
      is_source;
      /*
      set to nonzero if it is a source (input) rather than a a
      destination (output)
      */
   
   af_bool
      delete_me;
      /*
      set to nonzero if the data contained inside should be deleted
      This should only be set by using 'alflac_destination_save_data'
      */
   
   ALFLAC_DESTINATION_FILL_FUNCTION *
      fill_function;
      /*
      Information for internal use about which fill function to use.
      This changes what format the output is in (mono or stereo; big
      or little endian, etc). See "fill_function.h" for more.
      
      You don't normally need to worry about this, it is set when
      'alflac_destination_set_*' is called. You can override the
      default with 'alflac_destination_set_fill_function_table'.
      */
   
   void *
      data;
      /*
      Single pointer to data. The type of data held here depends on
      the value of "type".
      
      ALFLAC_DESTINATION_TYPE_FILE
         Is a FILE
      
      ALFLAC_DESTINATION_TYPE_DATAFILE
         Is an Allegro DATAFILE object
      
      ALFLAC_DESTINATION_TYPE_AUDIOSTREAM
         Is an ALFLAC_AUDIOSTREAM object. The ALFLAC_AUDIOSTREAM data
         is created when 'alflac_datafile_set_*' is called (but the
         allegro AUDIOSTREAM structure inside is set up later).
      
      ALFLAC_DESTINATION_TYPE_MEMORY_BUFFER
         Is an ALFLAC_BUFFER structure, which should be set up by the
         user.
      
      ALFLAC_DESTINATION_TYPE_PACKFILE
         Is an Allegro PACKFILE, opened for reading (sources) or
         writing (destinations).
      
      ALFLAC_DESTINATION_TYPE_BORROW_DATAFILE
         Is an ALFLAC_BUFFER arround the DATAFILE object. On exit, the
         DATAFILE object is NOT deleted, but the ALFLAC_BUFFER wrapper
         is deleted.
      */
      
      
   ALFLAC_DESTINATION *
      duplicate_destination_1;
   ALFLAC_DESTINATION *
      duplicate_destination_2;
      /*
      if "type" is ALFLAC_DESTINATION_TYPE_DUPLICATE, then
      the two destinations here are used.
      */

};


#ifdef ALFLAC_INTERNAL
/*
   This is an opaque structure, don't touch the values within!
*/
struct stALFLAC_DESTINATION_FILL_FUNCTION {
   ALFLAC_FILL_FUNCTION *
      fill_function;
      /* fill_function
         You don't need to set this - just set
         fill_function_table. Used for copying each frame of audio data
         to the buffer (eg FLAC 32 bit buffer --> Allegro 8/16 bit buffer).
      */
   
   af_uint
      output_frame_size; 
      /* output_frame_size
         The size, in bytes, of the output of each frame of data
         from the fill_function. This is so the output buffer can
         be incremented correctly for each time
      */
   
   ALFLAC_FILL_FUNCTION_PICKER *
      fill_function_table;
      /* fill_function_table
         A lookup table to pick the best fill function avaliable.
         Fill function is chosen when "info" is filled.
         End the list with 0, 0, NULL.
      */ 
};
#endif


ALFLAC_API ALFLAC_DESTINATION *alflac_destination_new(af_bool is_source);
ALFLAC_API void alflac_destination_del(ALFLAC_DESTINATION *d);
ALFLAC_API void alflac_destination_save_data(ALFLAC_DESTINATION *d);

ALFLAC_API int alflac_destination_ready_for_data_read(ALFLAC_DESTINATION *d);
ALFLAC_API int alflac_destination_ready_for_data_write(ALFLAC_DESTINATION *d);
#ifdef ALFLAC_INTERNAL
ALFLAC_ONLY void alflac_destination_end_of_stream(ALFLAC_DESTINATION *d);
#endif

ALFLAC_API int alflac_destination_set_fill_function_table(ALFLAC_DESTINATION *dest, ALFLAC_FILL_FUNCTION_PICKER *pick) ;
ALFLAC_API af_uint alflac_destination_frame_size(ALFLAC_DESTINATION *dest) ;
#ifdef ALFLAC_INTERNAL
ALFLAC_ONLY void alflac_destination_pick_function_from_table(ALFLAC_DESTINATION *dest, ALFLAC_INFO *info);
#endif

ALFLAC_API int alflac_destination_set_nothing(ALFLAC_DESTINATION *d);
ALFLAC_API int alflac_destination_set_audiostream(ALFLAC_DESTINATION *d, af_uint buffer_size);
ALFLAC_API int alflac_destination_set_memory_buffer(ALFLAC_DESTINATION *d, ALFLAC_BUFFER *buf);
ALFLAC_API int alflac_destination_set_packfile(ALFLAC_DESTINATION *d, PACKFILE *pack);
ALFLAC_API int alflac_destination_set_console(ALFLAC_DESTINATION *d);
ALFLAC_API int alflac_destination_set_duplicate(ALFLAC_DESTINATION *d, ALFLAC_DESTINATION **dup1, ALFLAC_DESTINATION **dup2);
ALFLAC_API int alflac_destination_set_file(ALFLAC_DESTINATION *d, FILE *fp);
ALFLAC_API int alflac_destination_set_borrow_datafile(ALFLAC_DESTINATION *d, DATAFILE *df, int df_index);


