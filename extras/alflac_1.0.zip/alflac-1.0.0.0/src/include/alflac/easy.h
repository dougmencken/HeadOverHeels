/*
   This header file is placed in the Public Domain.
   ALFLAC and libFLAC are licensed under the Xiph License.
*/

ALFLAC_API void alflac_for_allegro();

ALFLAC_API ALFLAC *alflac_do_file_to_audiostream(char *name, af_uint buffer_size);
ALFLAC_API ALFLAC *alflac_do_file_to_audiostream_and_console(char *name, af_uint buffer_size);
ALFLAC_API ALFLAC *alflac_do_datafile_to_audiostream(DATAFILE *df, int df_index, af_uint buffer_size);
ALFLAC_API SAMPLE *alflac_do_file_to_sample(const char *filename);
ALFLAC_API SAMPLE *alflac_do_packfile_to_sample(PACKFILE *pf);

