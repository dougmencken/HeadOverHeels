/*
   This header file is placed in the Public Domain.
   ALFLAC and libFLAC are licensed under the Xiph License.
*/


#ifdef ALFLAC_INTERNAL
/*
function to use inside alflac when there is an error.
*/
ALFLAC_ONLY void alflac_error_god(char *format, ...);
#endif

/*
ALFLAC errors get chucked on stderr by default.

Set my_alflac_error_function to your own function to do something
else. "error" here is a null-terminated error message, without a
trailing newline.

Set my_alflac_error_function to NULL to write to stderr again.
*/
ALFLAC_API void (* my_alflac_error_function) (const char *error);


