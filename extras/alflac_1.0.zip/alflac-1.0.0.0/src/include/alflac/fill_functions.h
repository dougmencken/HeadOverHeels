/*
   This header file is placed in the Public Domain.
   ALFLAC and libFLAC are licensed under the Xiph License.
*/

struct stALFLAC_FILL_FUNCTION_PICKER {
   af_byte
      bits;
      /*
      number of bits per channel per audio frame
      */
   af_byte
      channels;
      /*
      the number of channels
      */
   af_uint
      output_frame_size;
      /*
      the size of the output from this function, in BYTES. This is used
      to supply values to "destination->fill_function.output_frame_size",
      which is used in 'alflac_fill_buffer_then_overflow' (and possibly
      elsewhere) to fill the output buffer(s) supplied.
      
      For allegro functions, the output_frame_size is expected to be
      ( (bits/8) * channels ).
      
      A zero value will cause 'alflac_fill_buffer_then_overflow' to
      fail.
      */
   ALFLAC_FILL_FUNCTION *
      fill_function;
      /*
      the fill function which can cope with these values
      */
};


ALFLAC_API ALFLAC_FILL_FUNCTION_PICKER fill_function_table_default[5];
ALFLAC_API ALFLAC_FILL_FUNCTION_PICKER fill_function_table_default_to_mono[5];
ALFLAC_API ALFLAC_FILL_FUNCTION_PICKER fill_function_table_big_endian[5];



ALFLAC_API void copy_frame_chan0_bit8           (af_byte *albuf, FLAC__int32 b1, FLAC__int32 b2);
ALFLAC_API void copy_frame_chan0_bit16i         (af_byte *albuf, FLAC__int32 b1, FLAC__int32 b2);
ALFLAC_API void copy_frame_chan0_bit16m         (af_byte *albuf, FLAC__int32 b1, FLAC__int32 b2);
ALFLAC_API void copy_frame_chan1_bit8           (af_byte *albuf, FLAC__int32 b1, FLAC__int32 b2);
ALFLAC_API void copy_frame_chan1_bit16i         (af_byte *albuf, FLAC__int32 b1, FLAC__int32 b2);
ALFLAC_API void copy_frame_chan1_bit16m         (af_byte *albuf, FLAC__int32 b1, FLAC__int32 b2);
ALFLAC_API void copy_frame_indep_bit8           (af_byte *albuf, FLAC__int32 b1, FLAC__int32 b2);
ALFLAC_API void copy_frame_indep_bit16i         (af_byte *albuf, FLAC__int32 b1, FLAC__int32 b2);
ALFLAC_API void copy_frame_indep_bit16m         (af_byte *albuf, FLAC__int32 b1, FLAC__int32 b2);
ALFLAC_API void copy_frame_indep_to_mono_bit8   (af_byte *albuf, FLAC__int32 b1, FLAC__int32 b2);
ALFLAC_API void copy_frame_indep_to_mono_bit16i (af_byte *albuf, FLAC__int32 b1, FLAC__int32 b2);
ALFLAC_API void copy_frame_indep_to_mono_bit16m (af_byte *albuf, FLAC__int32 b1, FLAC__int32 b2);

