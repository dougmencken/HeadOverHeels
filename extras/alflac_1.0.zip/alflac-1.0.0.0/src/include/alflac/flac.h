/*
   This header file is placed in the Public Domain.
   ALFLAC and libFLAC are licensed under the Xiph License.
*/

#ifdef ALFLAC_INTERNAL

struct stALFLAC_FLAC {
   /* ALFLAC_FLAC
      Opaque wrapper for flac decoder (and other FLAC stuff).
      (this is so nobody needs the libFLAC header files)
   */
   
#ifdef FLAC__STREAM_DECODER_H
   FLAC__StreamDecoder *
#else
   void *
#endif
      decoder;
      /* decoder
         libFLAC stream decoder.
      */
      
      
   af_bool
      reached_end_of_stream;
      /* reached_end_of_stream
         If the source has reached the end of the stream, this will be
         set. Note that several more polls may be required before all
         the output data is written.
      */
};

   

ALFLAC_ONLY ALFLAC_FLAC *alflac_flac_new(ALFLAC *alflac);
ALFLAC_ONLY void alflac_flac_del(ALFLAC_FLAC *z);
ALFLAC_ONLY int alflac_flac_setup_decoder(ALFLAC_FLAC *z, ALFLAC *alflac);
ALFLAC_ONLY int alflac_flac_process(ALFLAC_FLAC *z, int to_end_of_stream);

#endif

