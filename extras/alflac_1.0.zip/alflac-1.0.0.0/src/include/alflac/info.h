/*
   This header file is placed in the Public Domain.
   ALFLAC and libFLAC are licensed under the Xiph License.
*/

struct stALFLAC_INFO {
   /* ALFLAC_STREAM_DATA
      Data to be set up when the STREAMINFO block has been read (ie on
      the first data block avaliable). These values are taken from the
      FLAC stream (ie, input) and not from the output.
      
      Setting this up requires that the bitrate, channels etc are
      known. It is set up only once, so the bitrate and channels should
      not change in the file.
      
      The functions which set this up also pick the
      fill_function.
   */
   
   
   af_byte
      channels;
      
   af_byte
      bits;
      
   af_uint
      frequency;

};


#ifdef ALFLAC_INTERNAL

ALFLAC_ONLY void alflac_info_del(ALFLAC_INFO *s);
ALFLAC_ONLY int alflac_info_set(ALFLAC *af, af_byte channels, af_byte bits, af_uint frequency);

#endif
