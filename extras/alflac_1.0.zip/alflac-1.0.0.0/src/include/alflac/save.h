/*
   This header file is placed in the Public Domain.
   ALFLAC and libFLAC are licensed under the Xiph License.
*/


ALFLAC_API int alflac_save_wav(const char *filename, SAMPLE *spl);
ALFLAC_API int alflac_save_wav_pf(PACKFILE *f, SAMPLE *spl);

