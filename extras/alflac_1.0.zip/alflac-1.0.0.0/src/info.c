/* ALFLAC - libFLAC for Allegro
 * Copyright (C) 2006, David Batley, CompuNach
 *
 * This code is avaliable for distribution under the Xiph License (below).
 *
 * You may also distribute the code below under the GNU General Public
 * License (GPL).
 * 
 * Xiph (BSD-style) License
 * ========================
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * - Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *
 * - Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 *
 * - Neither the name of the Xiph.org Foundation nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE FOUNDATION OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include <alflac/_internal.h>

/* local proto */
ALFLAC_INFO *alflac_info_new_internal(af_byte channels, af_byte bits, af_uint frequency);
void function_for_destination(ALFLAC_DESTINATION *dest, ALFLAC_INFO *info);



/* functions */
ALFLAC_INFO *alflac_info_new_internal(af_byte channels, af_byte bits, af_uint frequency){
   /* alflac_info_new
      Sets up the functions needed to copy data from flac to an audio buffer.
      Don't call this, call alflac_info_set instead
   */
   ALFLAC_INFO *s = malloc(sizeof(ALFLAC_INFO));
   if (!s)
      return NULL;
   
   s->channels = channels;
   s->bits = bits;
   s->frequency = frequency;
   
   
   return s;
}

void alflac_info_del(ALFLAC_INFO *s){
   /* alflac_info_del
      deletes "s"
   */
   free(s);
}

int alflac_info_set(ALFLAC *af, af_byte channels, af_byte bits, af_uint frequency){
   /*
   Sets up info on "af", creating a new ALFLAC_INFO and setting the
   right fill_function.
   
   Returns  Zero     on success
            Nonzero  on falure
   */
   if (!af) {
      alflac_error_god("info: No ALFLAC");
      return 9;
   }
   if (af->info) {
      alflac_error_god("info already exists. Do NOT call _info_new, ONLY call _info_set.");
      return 10;
   }
   
   af->info = alflac_info_new_internal(channels, bits, frequency);
   if (!af->info) {
      alflac_error_god("info creation failure");
      return -99;
   }
   
   /* pick fill_function for destination */
   alflac_destination_pick_function_from_table(af->destination, af->info); 
   
   return 0;
}



