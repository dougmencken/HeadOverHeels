/*

save.c
======

I give you permission to place these functions in your own projects
under any of the following licenses:
 * Allegro Giftware license
 * GNU Lesser General Public License
 * GNU General Public License 
 * Xiph License.

This file only depends on Allegro. It provides functions which aren't
in Allegro 4.2.0, but probably should be.

To wit,
 " I can't believe it's not....
         ______   ___    ___
        /\  _  \ /\_ \  /\_ \
        \ \ \L\ \\//\ \ \//\ \      __     __   _ __   ___    "
         \ \  __ \ \ \ \  \ \ \   /'__`\ /'_ `\/\`'__\/ __`\
          \ \ \/\ \ \_\ \_ \_\ \_/\  __//\ \L\ \ \ \//\ \L\ \
           \ \_\ \_\/\____\/\____\ \____\ \____ \ \_\\ \____/
            \/_/\/_/\/____/\/____/\/____/\/___L\ \/_/ \/___/
                                           /\____/
                                           \_/__/


*/

/* for the .dll stuff, use the normal headers */
#include <alflac/_internal.h>

/* functions*/
int alflac_save_wav(const char *filename, SAMPLE *spl){
   /*
   Saves "spl" as PCM WAVE in a new file "filename".
   
   Returns nonzero on error.   
   */
   
   PACKFILE *f;
   int r;
   
   f = pack_fopen(filename, F_WRITE);
   r = alflac_save_wav_pf(f, spl);
   pack_fclose(f);
   
   return r;
}

int alflac_save_wav_pf(PACKFILE *f, SAMPLE *spl){
   /*
   Saves "spl" as PCM WAVE in "f".
   
   Returns nonzero on error.   
   */
   
   long data_size, chans, bytes, i;
   
   if (!f || !spl)
      return 1;
   
   bytes = (spl->bits+7) /8;
   chans = spl->stereo?2:1;
   data_size = spl->len * bytes * chans;
   
   if (
      pack_fwrite("RIFF", 4, f)
   != 4)
      return 40;
   
   /* size of "WAVE" onwards (ie, filesize - 8; or data+36
      MSB=RHS => Little endian */
   if (
      pack_iputl(data_size + 36 , f)
   == EOF)
      return 41;

   if (
      pack_fwrite("WAVEfmt ", 8, f)
   != 8)
      return 42;
   
   /* size of "fmt " chunk (== 16)
      MSB=RHS => Little endian */
   if (
      pack_iputl(16, f)
   == EOF)
      return 43;
   
   /* format == PCM WAE (== 1) */
   if (
      pack_iputw(1, f)
   == EOF)
      return 44;

   /* channels */
   if (
      pack_iputw(chans, f)
   == EOF)
      return 45;

   /* freq */
   if (
      pack_iputl(spl->freq, f)
   == EOF)
      return 46;

   /* bytes per second == freq * channels * (bits/8) */
   if (
      pack_iputl(spl->freq * chans * bytes, f)
   == EOF)
      return 46;

   /* bytes per frame == channels * (bits/8) */
   if (
      pack_iputw(chans * bytes, f)
   == EOF)
      return 46;

   /* bits per channel (8 or 16) */
   if (
      pack_iputw(spl->bits, f)
   == EOF)
      return 46;

   /* "data" chunk */
   if (
      pack_fwrite("data", 4, f)
   != 4)
      return 40;
   
   /* size of "data " chunk */
   if (
      pack_iputl(data_size, f)
   == EOF)
      return 43;
   
   /* data */
   switch (spl->bits) {
      case 8:
         /* UNSIGNED, LITTLE ENDIAN */
         if (
            pack_fwrite(spl->data, data_size, f)
         != data_size)
            return 50;
         break;
      case 16:
      {
         /* SIGNED, LITTLE ENDIAN */
         unsigned char *data = spl->data;
         signed int out;
         
         for (i = 0; i < spl->len * chans; i++){
            /* foreach (frame) */
            
            out = (data[0]) + (data[1]<<8);
            
            /* change from values of 0..0xffff to -0x8000 .. +0x7fff
               ie, change unsigned_16 -> signed_16.
               nb, this is the exact opposite of the fill_functions. */
            out -= 0x8000;
            
            pack_iputw(out, f);
            
            data += bytes;
         }
         break;
      }
      case 32:
      {
         /* SIGNED, LITTLE ENDIAN */
         unsigned char *data = spl->data;
         signed long out;
         
         for (i = 0; i < spl->len * chans; i++){
            /* foreach (frame) */
            
            out = (data[0]) + (data[1]<<8) + (data[1]<<16) + (data[1]<<24);
            
            /* change from values of 0..0xffff to -0x8000 .. +0x7fff
               ie, change unsigned_16 -> signed_16.
               nb, this is the exact opposite of the fill_functions. */
            out -= 0x80000000;
            
            pack_iputl(out, f);
            
            data += bytes;
         }
         break;
      }
      default:
         return 70;
   }
   
   /* ok */
   return 0;
}

